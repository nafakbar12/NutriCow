<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProducelogTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('producelog', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('bovine_id');
            $table->unsignedBigInteger('from_user_id');
            $table->foreign('from_user_id')->references('id')->on('users');
            $table->unsignedBigInteger('to_user_id');
            $table->foreign('to_user_id')->references('id')->on('users');
            $table->unsignedBigInteger('farmer_bovine_type_id');
            $table->foreign('farmer_bovine_type_id')->references('id')->on('farmer_bovine');
            $table->dateTime('transaction_date');
            $table->float('quantity', 10,2)->default(0);
            $table->float('fat', 10,2)->default(0);
            $table->float('snf', 10,2)->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('farmer_produce');
    }
}
