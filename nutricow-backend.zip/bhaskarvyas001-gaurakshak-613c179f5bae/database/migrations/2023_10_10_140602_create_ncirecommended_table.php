<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateNciRecommendedTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('nci_recommendeds', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('bovine_type_id');
            $table->foreign('bovine_type_id')->references('id')->on('bovines');
            $table->unsignedBigInteger('state_id');
            $table->foreign('state_id')->references('id')->on('states');
            $table->boolean('ismilking')->default(1);
            $table->float('milk_yield', 10,2)->default(0);
            $table->float('body_weight', 10,2)->default(0);
            $table->float('fat', 10,2)->default(0);
            $table->float('dm', 10,2)->default(0);
            $table->float('dcp', 10,2)->default(0);
            $table->float('tdn', 10,2)->default(0);
            $table->float('ca', 10,2)->default(0);
            $table->float('p', 10,2)->default(0);
            $table->float('salt', 10,2)->default(0);
            $table->float('yp', 10,2)->default(0);
            $table->boolean('isdeleted')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('nci_recommendeds');
    }
}
