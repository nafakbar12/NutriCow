<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateNciNutricheckTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('nci_nutrichecks', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('category_id');
            $table->foreign('category_id')->references('id')->on('nci_categorys');
            $table->unsignedBigInteger('fodder_id');
            $table->foreign('fodder_id')->references('id')->on('nci_fodders');
            $table->unsignedBigInteger('state_id');
            $table->foreign('state_id')->references('id')->on('states');
            $table->float('dm', 10,2)->default(0);
            $table->float('dcp', 10,2)->default(0);
            $table->float('tdn', 10,2)->default(0);
            $table->float('ca', 10,2)->default(0);
            $table->float('p', 10,2)->default(0);
            $table->float('cp', 10,2)->default(0);
            $table->boolean('isdeleted')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('nci_nutrichecks');
    }
}
