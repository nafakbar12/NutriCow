<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;


/**
 * @property integer $id
 * @property string $name
 * @property string $mobile
 * @property string $mobile_verified_at
 * @property string $password
 * @property string $api_token
 * @property string $user_type
 * @property string $remember_token
 * @property string $created_at
 * @property string $updated_at
 * @property Profile[] $profiles
 */
class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'mobile', 'password', 'user_type'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'mobile_verified_at' => 'datetime',
    ];

    public function generateToken()
    {
        $this->api_token = str_random(60);
        $this->save();
        return $this->api_token;
    }

    public function scopeOfUser($query, $id){
        return $query->where('id', $id);
    }

    public function profiles()
    {
        return $this->hasOne('App\Profile');
    }
}
