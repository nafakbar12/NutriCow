<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property integer $id
 * @property integer $village_id
 * @property integer $zone_id
 * @property integer $district_id
 * @property integer $state_id
 * @property integer $country_id
 * @property string $location_type
 * @property string $mobile
 * @property string $phone
 * @property string $email
 * @property string $address
 * @property string $pincode
 * @property string $created_at
 * @property string $updated_at
 * @property Country $country
 * @property District $district
 * @property State $state
 * @property Village $village
 * @property Zone $zone
 * @property Bmc $bmc
 * @property Dairy $dairie
 * @property Farmer $farmer
 * @property Vlcc $vlcc
 */
class Address extends Model
{
    /**
     * The "type" of the auto-incrementing ID.
     * 
     * @var string
     */
    protected $keyType = 'integer';

    /**
     * @var array
     */
    protected $fillable = ['village_id', 'zone_id', 'district_id', 'state_id', 'country_id', 'location_type', 'mobile', 'phone', 'email', 'address', 'pincode', 'name'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function country()
    {
        return $this->belongsTo('App\Country');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function district()
    {
        return $this->belongsTo('App\District');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function state()
    {
        return $this->belongsTo('App\State');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function village()
    {
        return $this->belongsTo('App\Village');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function zone()
    {
        return $this->belongsTo('App\Zone');
    }
}
