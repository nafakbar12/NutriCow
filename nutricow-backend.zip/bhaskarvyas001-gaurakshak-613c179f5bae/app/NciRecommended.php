<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property integer $id
 * @property integer $bovine_type_id
 * @property integer $state_id
 * @property boolean $ismilking
 * @property float $milk_yield
 * @property float $body_weight
 * @property float $fat
 * @property float $dm
 * @property float $dcp
 * @property float $tdn
 * @property float $ca
 * @property float $p
 * @property float $salt
 * @property float $yp
 * @property boolean $isdeleted
 * @property string $created_at
 * @property string $updated_at
 * @property Bovine $bovine
 * @property State $state
 */
class NciRecommended extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'nci_recommendeds';

    /**
     * The "type" of the auto-incrementing ID.
     * 
     * @var string
     */
    protected $keyType = 'integer';

    /**
     * @var array
     */
    protected $fillable = ['bovine_type_id', 'state_id', 'ismilking', 'milk_yield', 'body_weight', 'fat', 'dm', 'dcp', 'tdn', 'ca', 'p', 'salt', 'yp', 'isdeleted', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function bovine()
    {
        return $this->belongsTo('App\Bovine', 'bovine_type_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function state()
    {
        return $this->belongsTo('App\State');
    }
}
