<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Address;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Debugbar;
use App\Error;

class AddressController extends Controller
{
    public function index(){
        //return Address::paginate(1000);
        return Address::all();
    }

    public function show($address_id)
    {
        return Address::where('id', '=', $address_id)->get();
    }

    public function store(Request $request)
    {
        $address = Address::create($request->all());
        return response()->json($address, 201);
    }

    public function update(Request $request, Address $address)
    {
        $address->update($request->all());
        return response()->json($address, 200);
    }

    public function delete($id)
    {
        $address = Address::findOrFail(input::get('id'));
        $address->delete();
        return response()->json(null, 204);
    }
}
