<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Profile;
use App\Address;
use App\FarmerBovine;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Debugbar;
use App\Error;
use DB;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    public function index(){
        //return User::paginate(1000);
        return User::all();
    }

    public function show($user_id)
    {
        return User::where('id', '=', $user_id)->get();
    }

    public function store(Request $request)
    {
        try {
            //if the request body is JSON
            $input = $request->json()->all();
            Debugbar::info("User data -". json_encode($input));
            DB::beginTransaction();
            //create the user in users table first
            //generate 8 Digit Random Number password
            //$password = mt_rand(10000000,99999999)
            $password = "12345678";
            $user = User::create([
                "name"  =>  $input['name'],
                "mobile"  => $input['profile']['mobile'],
                "password" => Hash::make($password),
                "user_type"  => $input['user_type']
            ]);
            Debugbar::info("User registered -". $user->id);

            //create address
            $address = Address::create([
                "location_type"  =>  $input['user_type'],
                "mobile"  => $input['profile']['mobile'],
                "phone" => isset($input['profile']['phone']) ? $input['profile']['phone'] : null,
                "email"  => $input['profile']['email'],
                "address"  =>  $input['profile']['address'],
                "pincode"  => $input['profile']['pincode'],
                "village_id" => $input['profile']['village_id'],
                "zone_id" => $input['profile']['zone_id'],
                "district_id" => $input['profile']['district_id'],
                "state_id" => $input['profile']['state_id'],
                "country_id" => $input['profile']['country_id'],
            ]);
            Debugbar::info("Address added -". $address->id);

            $profileData = new \stdClass();
            $profileData->date_of_birth = $input['dateOfBirth'];
            $profileData->aadhar_number = $input['aadharNumber'];
            
            if($input['user_type'] != "Farmer"){
                $profile = Profile::create([
                    "user_id" => $user->id,
                    "address_id" => $address->id,
                    "profile_image" => null,
                    "profile_data" => json_encode($profileData)
                ]);
                Debugbar::info("Profie added -". $profile->id);
            }else{
                $profileData->biometric = $input['profile']['biometric'];
                $profileData->bank_name = $input['profile']['bankName'];
                $profile = Profile::create([
                    "user_id" => $user->id,
                    "address_id" => $address->id,
                    "profile_image" => null,
                    "profile_data" => json_encode($profileData)
                ]);
                Debugbar::info("Profie added -". $profile->id);

                $bovineData = new \stdClass();
                $bovineData->count = $input['bovine']['count'];
                $bovineData->herdInfo = $input['bovine']['herdInfo'];
                $bovineData->feed = $input['bovine']['feed'];
                $farmerBovine = FarmerBovine::create([
                    "user_id" => $user->id,
                    "bovine_id" => $input['bovine']['bovine_id'],
                    "biometric" => $input['bovine']['biometric'],
                    "bovine_profile" => json_encode($bovineData)
                ]);
                Debugbar::info("Farmer Bovine added -". $farmerBovine->id);
            }

            DB::commit();
        } catch (\Exception $ex) {
            DB::rollback();
            $error = Error::make(['error' => $ex->getMessage(),"line" => $ex->getLine(),"file" =>$ex->getFile()]);
            return response()->json($error, 200);
        }
        return response()->json($user, 201);
    }

    public function update(Request $request, User $user)
    {
        $user->update($request->all());
        return response()->json($user, 200);
    }

    public function delete($id)
    {
        $user = User::findOrFail(input::get('id'));
        $user->delete();
        return response()->json(null, 204);
    }
}
