<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\OrderItem;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Debugbar;
use App\Error;

class OrderItemController extends Controller
{
    public function index(){
        // return OrderItemProduce::paginate(1000);
         return OrderItem::all();
     }
 
     public function show($orderitem_id)
     {
         return OrderItem::where('id', '=', $orderitem_id)->get();
     }
 
     public function store(Request $request)
     {
         $orderitem = OrderItem::create($request->all());
         return response()->json($orderitem, 201);
     }
 
     public function update(Request $request, OrderItem $orderitem)
     {
         $orderitem->update($request->all());
         return response()->json($orderitem, 200);
     }
 
     public function delete($id)
     {
         $orderitem = OrderItem::findOrFail(input::get('id'));
         $orderitem->delete();
         return response()->json(null, 204);
     }
}
