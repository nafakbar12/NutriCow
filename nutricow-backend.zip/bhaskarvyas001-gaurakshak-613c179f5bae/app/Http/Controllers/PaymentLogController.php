<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\PaymentLog;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Debugbar;
use App\Error;

class PaymentLogController extends Controller
{
    public function index(){
        //return PaymentLog::paginate(1000);
        return PaymentLog::all();
    }

    public function show($paymentlog_id)
    {
        return PaymentLog::where('id', '=', $paymentlog_id)->get();
    }

    public function store(Request $request)
    {
        $paymentlog = PaymentLog::create($request->all());
        return response()->json($paymentlog, 201);
    }

    public function update(Request $request, PaymentLog $paymentlog)
    {
        $paymentlog->update($request->all());
        return response()->json($paymentlog, 200);
    }

    public function delete($id)
    {
        $paymentlog = PaymentLog::findOrFail(input::get('id'));
        $paymentlog->delete();
        return response()->json(null, 204);
    }
}
