<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\NciFodder;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Debugbar;
use App\Error;

class NciFodderController extends Controller
{
    public function index(){
        //return NciFodder::paginate(1000);
        return NciFodder::with('nciCategory')->with('nciSubcategory')->get();
    }

    public function show($ncifodder_id)
    {
        return NciFodder::where('id', '=', $ncifodder_id)->with('nciCategory')->with('nciSubcategory')->get();
    }

    public function store(Request $request)
    {
        $ncifodder = NciFodder::create($request->all());
        return response()->json($ncifodder, 201);
    }

    public function update(Request $request, NciFodder $ncifodder)
    {
        $ncifodder->update($request->all());
        return response()->json($ncifodder, 200);
    }

    public function delete($id)
    {
        $ncifodder = NciFodder::findOrFail(input::get('id'));
        $ncifodder->delete();
        return response()->json(null, 204);
    }
}
