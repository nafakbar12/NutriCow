<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Village;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Debugbar;
use App\Error;

class VillageController extends Controller
{
    public function index(){
        //return Village::paginate(1000);
        return Village::all();
    }

    public function show($village_id)
    {
        return Village::where('id', '=', $village_id)->get();
    }

    public function store(Request $request)
    {
        $village = Village::create($request->all());
        return response()->json($village, 201);
    }

    public function update(Request $request, Village $village)
    {
        $village->update($request->all());
        return response()->json($village, 200);
    }

    public function delete($id)
    {
        $village = Village::findOrFail(input::get('id'));
        $village->delete();
        return response()->json(null, 204);
    }
}
