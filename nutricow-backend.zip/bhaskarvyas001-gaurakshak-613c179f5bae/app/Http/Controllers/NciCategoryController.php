<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\NciCategory;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Debugbar;
use App\Error;

class NciCategoryController extends Controller
{
    public function index(){
        //return NciCategory::paginate(1000);
        return NciCategory::all();
    }

    public function show($ncicategory_id)
    {
        return NciCategory::where('id', '=', $ncicategory_id)->get();
    }

    public function store(Request $request)
    {
        $ncicategory = NciCategory::create($request->all());
        return response()->json($ncicategory, 201);
    }

    public function update(Request $request, NciCategory $ncicategory)
    {
        $ncicategory->update($request->all());
        return response()->json($ncicategory, 200);
    }

    public function delete($id)
    {
        $ncicategory = NciCategory::findOrFail(input::get('id'));
        $ncicategory->delete();
        return response()->json(null, 204);
    }
}
