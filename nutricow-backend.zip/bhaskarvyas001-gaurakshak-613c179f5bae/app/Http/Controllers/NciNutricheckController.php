<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Profile;
use App\Address;
use App\NciNutricheck;
use App\NciRecommended;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Debugbar;
use App\Error;

class NciNutricheckController extends Controller
{
    public function index(){
        //return NciNuticheck::paginate(1000);
        return NciNuticheck::all();
    }

    public function show($ncinutricheck_id)
    {
        return NciNuticheck::where('id', '=', $ncinutricheck_id)->get();
    }

    public function store(Request $request)
    {
        $ncinutricheck = NciNuticheck::create($request->all());
        return response()->json($ncinutricheck, 201);
    }

    public function update(Request $request, NciNuticheck $ncinutricheck)
    {
        $ncinutricheck->update($request->all());
        return response()->json($ncinutricheck, 200);
    }

    public function delete($id)
    {
        $ncinutricheck = NciNuticheck::findOrFail(input::get('id'));
        $ncinutricheck->delete();
        return response()->json(null, 204);
    }

    public function nutricheck(Request $request){
        $user = Auth::user();
        $profile = Profile::where('user_id', $user->id)->firstOrFail();
        $address = Address::where('id', $profile->address_id)->firstOrFail();
        $stateId = $address->state_id;
        $nutrichecks = array();
        $result = new \stdClass();
        $result->dm = 0;
        $result->tdn = 0;
        $result->cal = 0;
        $result->dcp = 0;
        $result->p = 0;
        $input = $request->json()->all();
        Debugbar::info( $input);
        foreach ($input['foddersSelected'] as $value) {
            $nutri = NciNutricheck::where("category_id",$value['category_id'])->where("fodder_id",$value["id"])->where("state_id",$stateId)->first();
            Debugbar::info($nutri);
            if(isset($nutri->dm)){
                Debugbar::info("calculating");
                array_push($nutrichecks, $nutri);
                $result->dm += round($value['quantity'] * ($nutri->dm/100));
                $result->tdn += round($value['quantity'] * ($nutri->tdn/100));
                $result->cal += round($value['quantity'] * ($nutri->ca/100));
                $result->dcp += round($value['quantity'] * ($nutri->dcp/100));
                $result->p += round($value['quantity'] * ($nutri->p/100));
            }
            Debugbar::info($result);
        }

        //now check the limits
        $recommendations = NciRecommended::where("bovine_type_id",$input['bovine_type'])->where("state_id",$stateId)
                    ->where("ismilking",$input["ismilking"])->where("milk_yield",$input["milk_yield"])
                    ->where("body_weight", $input['bovine_weight'])->first();
        if(isset($recommendations->dm)){
            Debugbar::info($recommendations);
            $result->recommendations = $recommendations;
        }else{
            $recommendations = new \stdClass();
            $recommendations->dm = 0;
            $recommendations->tdn = 0;
            $recommendations->ca = 0;
            $recommendations->dcp = 0;
            $recommendations->p = 0;
            $result->recommendations = $recommendations;
        }
        return response()->json($result, 200);
    }

    public function watsonSpeechtoText(Request $request){
        Debugbar::info($request);
        Debugbar::info($request->file('audio'));
        $gstimage_path = null;
        if(!empty($request->file('audio'))){
            $gstfileName = $request->file('audio')->getClientOriginalName();
            $request->audio->move(public_path('audio'), $gstfileName);
            //$gstimage_path = "/audio/audio-file.flac";
            $gstimage_path = "/audio/$gstfileName";
        }
        Debugbar::info($gstimage_path);
        $publicPath = public_path($gstimage_path);;
        //$audio = fopen($publicPath, 'r');

        //$file_extention = "flac";
        $file_extention = "mp3";

        $file = fopen($publicPath, 'r');

        $filesize = filesize($publicPath);

        $bytes = fread($file,$filesize);

        $headers = array('Authorization: Basic YXBpa2V5OmdETm5aWXlPcG9sVVJaZElSQlpKMUlYQTY1Vm5zYXQ5SVJNRW5TN1Y5U3dn', 
                          "Content-Type: audio/".$file_extention ,
                          "Transfer-Encoding: chunked"); // ,"Transfer-Encoding: binary"

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://api.au-syd.speech-to-text.watson.cloud.ibm.com/instances/8a84e3f1-c07d-4ab2-9c02-fca663b54505/v1/recognize');
        //curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_BINARYTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $bytes);
        curl_setopt($ch, CURLOPT_INFILESIZE, $filesize);
        curl_setopt($ch, CURLOPT_VERBOSE, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        curl_close($ch);

        /*$curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://api.au-syd.speech-to-text.watson.cloud.ibm.com/instances/8a84e3f1-c07d-4ab2-9c02-fca663b54505/v1/recognize',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => $audio,
        CURLOPT_HTTPHEADER => array(
            'Content-Type: audio/mpeg',
            'Authorization: Basic YXBpa2V5OmdETm5aWXlPcG9sVVJaZElSQlpKMUlYQTY1Vm5zYXQ5SVJNRW5TN1Y5U3dn'
        ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);*/
        
        Debugbar::info($response);
        $response = json_decode($response);
        $result = $response->results[0]->alternatives[0]->transcript;
        Debugbar::info("returning -->".$result);

        return response()->json($result, 200);
    }
}
