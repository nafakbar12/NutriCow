<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\NciSubcategory;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Debugbar;
use App\Error;

class NciSubcategoryController extends Controller
{
    public function index(){
        //return NciSubcategory::paginate(1000);
        return NciSubcategory::all();
    }

    public function show($ncisubcategory_id)
    {
        return NciSubcategory::where('id', '=', $ncisubcategory_id)->get();
    }

    public function store(Request $request)
    {
        $ncisubcategory = NciSubcategory::create($request->all());
        return response()->json($ncisubcategory, 201);
    }

    public function update(Request $request, NciSubcategory $ncisubcategory)
    {
        $ncisubcategory->update($request->all());
        return response()->json($ncisubcategory, 200);
    }

    public function delete($id)
    {
        $ncisubcategory = NciSubcategory::findOrFail(input::get('id'));
        $ncisubcategory->delete();
        return response()->json(null, 204);
    }
}
