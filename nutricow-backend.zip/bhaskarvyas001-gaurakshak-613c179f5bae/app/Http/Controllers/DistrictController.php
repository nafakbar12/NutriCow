<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\District;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Debugbar;
use App\Error;

class DistrictController extends Controller
{
    public function index(){
        //return District::paginate(1000);
        return District::all();
    }

    public function show($district_id)
    {
        return District::where('id', '=', $district_id)->get();
    }

    public function store(Request $request)
    {
        $district = District::create($request->all());
        return response()->json($district, 201);
    }

    public function update(Request $request, District $district)
    {
        $district->update($request->all());
        return response()->json($district, 200);
    }

    public function delete($id)
    {
        $district = District::findOrFail(input::get('id'));
        $district->delete();
        return response()->json(null, 204);
    }
}
