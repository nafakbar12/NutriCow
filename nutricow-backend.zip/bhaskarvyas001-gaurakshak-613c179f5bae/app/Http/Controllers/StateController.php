<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\State;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Debugbar;
use App\Error;

class StateController extends Controller
{
    public function index(){
        //return State::paginate(1000);
        return State::all();
    }

    public function show($state_id)
    {
        return State::where('id', '=', $state_id)->get();
    }

    public function store(Request $request)
    {
        $state = State::create($request->all());
        return response()->json($state, 201);
    }

    public function update(Request $request, State $state)
    {
        $state->update($request->all());
        return response()->json($state, 200);
    }

    public function delete($id)
    {
        $state = State::findOrFail(input::get('id'));
        $state->delete();
        return response()->json(null, 204);
    }
}
