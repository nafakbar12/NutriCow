<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Profile;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Debugbar;
use App\Error;

class ProfileController extends Controller
{
    public function index(){
        //return Profile::paginate(1000);
        return Profile::all();
    }

    public function show($profile_id)
    {
        return Profile::where('id', '=', $profile_id)->get();
    }

    public function store(Request $request)
    {
        $profile = Profile::create($request->all());
        return response()->json($profile, 201);
    }

    public function update(Request $request, Profile $profile)
    {
        $profile->update($request->all());
        return response()->json($profile, 200);
    }

    public function delete($id)
    {
        $profile = Profile::findOrFail(input::get('id'));
        $profile->delete();
        return response()->json(null, 204);
    }
}
