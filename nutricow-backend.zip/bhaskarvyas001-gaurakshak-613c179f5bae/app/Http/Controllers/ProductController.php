<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Product;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Debugbar;
use App\Error;

class ProductController extends Controller
{
    public function index(Request $request){
        // return ProductProduce::paginate(1000);
        $productType = $request->query('productType');
        if( $productType){
            return Product::where('type',$productType)->get();    
        }
        return Product::all();
     }
 
     public function show($product_id)
     {
         return Product::where('id', '=', $product_id)->get();
     }
 
     public function store(Request $request)
     {
         $product = Product::create($request->all());
         return response()->json($product, 201);
     }
 
     public function update(Request $request, Product $product)
     {
         $product->update($request->all());
         return response()->json($product, 200);
     }
 
     public function delete($id)
     {
         $product = Product::findOrFail(input::get('id'));
         $product->delete();
         return response()->json(null, 204);
     }
}
