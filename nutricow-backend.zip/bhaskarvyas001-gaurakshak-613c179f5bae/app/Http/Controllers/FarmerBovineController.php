<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\FarmerBovine;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Debugbar;
use App\Error;

class FarmerBovineController extends Controller
{
    public function index(){
       // return FarmerBovine::paginate(1000);
        return FarmerBovine::all();
    }

    public function show($farmerbovine_id)
    {
        return FarmerBovine::where('id', '=', $farmerbovine_id)->get();
    }

    public function store(Request $request)
    {
        $farmerbovine = FarmerBovine::create($request->all());
        return response()->json($farmerbovine, 201);
    }

    public function update(Request $request, FarmerBovine $farmerbovine)
    {
        $farmerbovine->update($request->all());
        return response()->json($farmerbovine, 200);
    }

    public function delete($id)
    {
        $farmerbovine = FarmerBovine::findOrFail(input::get('id'));
        $farmerbovine->delete();
        return response()->json(null, 204);
    }
}
