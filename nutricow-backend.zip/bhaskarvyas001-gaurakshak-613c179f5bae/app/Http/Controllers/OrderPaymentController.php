<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\OrderPayment;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Debugbar;
use App\Error;

class OrderPaymentController extends Controller
{
    public function index(){
        // return OrderPaymentProduce::paginate(1000);
         return OrderPayment::all();
     }
 
     public function show($orderpayment_id)
     {
         return OrderPayment::where('id', '=', $orderpayment_id)->get();
     }
 
     public function store(Request $request)
     {
         $orderpayment = OrderPayment::create($request->all());
         return response()->json($orderpayment, 201);
     }
 
     public function update(Request $request, OrderPayment $orderpayment)
     {
         $orderpayment->update($request->all());
         return response()->json($orderpayment, 200);
     }
 
     public function delete($id)
     {
         $orderpayment = OrderPayment::findOrFail(input::get('id'));
         $orderpayment->delete();
         return response()->json(null, 204);
     }
}
