<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\ProduceLog;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Debugbar;
use App\Error;

class ProduceLogController extends Controller
{
    public function index(){
        // return ProduceLogProduce::paginate(1000);
         return ProduceLog::all();
     }
 
     public function show($producelog_id)
     {
         return ProduceLog::where('id', '=', $producelog_id)->get();
     }
 
     public function store(Request $request)
     {
         $producelog = ProduceLog::create($request->all());
         return response()->json($producelog, 201);
     }
 
     public function update(Request $request, ProduceLog $producelog)
     {
         $producelog->update($request->all());
         return response()->json($producelog, 200);
     }
 
     public function delete($id)
     {
         $producelog = ProduceLog::findOrFail(input::get('id'));
         $producelog->delete();
         return response()->json(null, 204);
     }
}
