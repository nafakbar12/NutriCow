<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\NciRecommended;
use App\Profile;
use App\Address;
use App\NciNutricheck;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Debugbar;
use App\Error;

class NciRecommendedController extends Controller
{
    public function index(){
        //return NciRecommended::paginate(1000);
        return NciRecommended::all();
    }

    public function show($ncirecommended_id)
    {
        return NciRecommended::where('id', '=', $ncirecommended_id)->get();
    }

    public function store(Request $request)
    {
        $ncirecommended = NciRecommended::create($request->all());
        return response()->json($ncirecommended, 201);
    }

    public function update(Request $request, NciRecommended $ncirecommended)
    {
        $ncirecommended->update($request->all());
        return response()->json($ncirecommended, 200);
    }

    public function delete($id)
    {
        $ncirecommended = NciRecommended::findOrFail(input::get('id'));
        $ncirecommended->delete();
        return response()->json(null, 204);
    }

    public function nutrirecommend(Request $request){
        $input = $request->json()->all();
        Debugbar::info($input);
        $user = Auth::user();
        $profile = Profile::where('user_id', $user->id)->firstOrFail();
        $address = Address::where('id', $profile->address_id)->firstOrFail();
        $stateId = $address->state_id;
        
        $curl = curl_init();

        curl_setopt_array($curl, array(
          CURLOPT_URL => 'http://3.26.42.100:5000/predict',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS =>'{
            "bw": '.$input['bovine_weight'].',
            "milk_yield": '.$input['milk_yield'].',
            "cattle_type": '.$input['bovine_type'].',
            "loc": '.$stateId.',
            "milking": '.$input['milking'].'
        }',
          CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json'
          ),
        ));
        
        $response = curl_exec($curl);
        Debugbar::info($response);

        curl_close($curl);
        $jsonResp = json_decode($response);
        $result = new \stdClass();
        $result->green_fodder = round($jsonResp->prediction[0][0]);
        $result->dry_fodder = round($jsonResp->prediction[0][1]);
        $result->concentrate = round($jsonResp->prediction[0][2]);
        $result->molasses = round($jsonResp->prediction[0][3]);
        $result->salt = round($jsonResp->prediction[0][4]);
        $result->yeast = round($jsonResp->prediction[0][5]);
        
        return response()->json($result, 200);
    }
}
