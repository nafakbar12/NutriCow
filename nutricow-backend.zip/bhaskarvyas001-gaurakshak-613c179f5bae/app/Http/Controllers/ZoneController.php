<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Zone;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Debugbar;
use App\Error;


class ZoneController extends Controller
{
    public function index(){
        //return Zone::paginate(1000);
        return Zone::all();
    }

    public function show($zone_id)
    {
        return Zone::where('id', '=', $zone_id)->get();
    }

    public function store(Request $request)
    {
        $zone = Zone::create($request->all());
        return response()->json($zone, 201);
    }

    public function update(Request $request, Zone $zone)
    {
        $zone->update($request->all());
        return response()->json($zone, 200);
    }

    public function delete($id)
    {
        $zone = Zone::findOrFail(input::get('id'));
        $zone->delete();
        return response()->json(null, 204);
    }
}
