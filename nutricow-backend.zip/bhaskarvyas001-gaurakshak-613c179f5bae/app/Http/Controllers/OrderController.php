<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Order;
use App\OrderItem;
use App\Product;
use App\Address;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Debugbar;
use App\Error;
use DB;

class OrderController extends Controller
{
    public function index(){
        // return OrderProduce::paginate(1000);
        //return Order::all();
        $user = Auth::user();
        return Order::where('user_id', '=', $user->id)->get();
     }
 
     public function show($order_id)
     {
        $user = Auth::user();
        return Order::where('user_id', '=', $user->id)->where('id', '=', $order_id)->get();
        //return Order::where('id', '=', $order_id)->get();
     }
 
     public function store(Request $request)
     {
        try {
            //if the request body is JSON
            $input = $request->json()->all();
            Debugbar::info("Order data -". json_encode($input));
            DB::beginTransaction();
            //create address
            $address = Address::create([
                "location_type"  =>  "Order",//$input['address']['location_type'],
                "mobile"  => $input['address']['mobile'],
                "phone" => isset($input['address']['phone']) ? $input['address']['phone'] : null,
                "email"  =>  isset($input['address']['email']) ? $input['address']['email'] : null,
                "address"  =>  $input['address']['address'],
                "pincode"  => $input['address']['pincode'],
                "village_id" => $input['address']['village_id'],
                "zone_id" => isset($input['address']['zone_id']) ? $input['address']['zone_id'] : null,
                "district_id" => $input['address']['district_id'],
                "state_id" => $input['address']['state_id'],
                "country_id" => $input['address']['country_id'],
            ]);
            Debugbar::info("Address added -". $address->id);

            //calculate total quantity and cost
            $totalCost = 0;
            $totalQuantity = 0;
            foreach ($input['order']['order_items'] as $value) {
                $product = Product::findOrFail($value['product_id']);
                $totalCost += $product->price * $value['quantity'];
                $totalQuantity += $value['quantity'];
            }

            //now create the order
            $order = Order::create([
                "user_id" => $input['order']['user_id'],
                "address_id" => $address->id,
                "quantity" => $totalQuantity,
                "total_cost" => $totalCost,
                "total_balance" => $totalCost
            ]);
            Debugbar::info("order created -". $order->id);

            //create order items
            foreach ($input['order']['order_items'] as $value) {
                $product = Product::findOrFail($value['product_id']);
                $orderItem = OrderItem::create([
                    "order_id" => $order->id,
                    "product_id" => $value['product_id'],
                    "quantity" => $value['quantity'],
                    "total_cost" => $product->price * $value['quantity']
                ]);
                Debugbar::info("order Item created -". $orderItem->id);
            }
            DB::commit();
        } catch (\Exception $ex) {
            DB::rollback();
            $error = Error::make(['error' => $ex->getMessage(),"line" => $ex->getLine(),"file" =>$ex->getFile()]);
            return response()->json($error, 200);
        }
        return response()->json($order, 201);
     }
 
     public function update(Request $request, Order $order)
     {
         $order->update($request->all());
         return response()->json($order, 200);
     }
 
     public function delete($id)
     {
         $order = Order::findOrFail(input::get('id'));
         $order->delete();
         return response()->json(null, 204);
     }
}
