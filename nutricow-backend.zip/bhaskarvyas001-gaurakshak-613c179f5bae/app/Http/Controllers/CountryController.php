<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Country;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Debugbar;
use App\Error;

class CountryController extends Controller
{
    public function index(){
        //return Country::paginate(1000);
        return Country::all();
    }

    public function show($country_id)
    {
        return Country::where('id', '=', $country_id)->get();
    }

    public function store(Request $request)
    {
        $country = Country::create($request->all());
        return response()->json($country, 201);
    }

    public function update(Request $request, Country $country)
    {
        $country->update($request->all());
        return response()->json($country, 200);
    }

    public function delete($id)
    {
        $country = Country::findOrFail(input::get('id'));
        $country->delete();
        return response()->json(null, 204);
    }
}
