<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Auth;
use App\User;
use Illuminate\Support\Facades\Hash;
use Debugbar;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/home';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    //custome method
    public function login(Request $request)
    {
        $this->validateLogin($request);

        //if ($this->attemptLogin($request)) {
        if(Auth::attempt(['mobile' => $request->mobile, 'password' => $request->password])){
            $user = $this->guard()->user();
            $user->generateToken();

            return response()->json([
                'data' => $user->toArray(),
            ]);
        }

        //during MVP we auto register the farmers if the password is moo
        /*if($request->password == "moo"){
            $user = User::create([
                "name"  =>  $request->mobile,
                "mobile"  => $request->mobile,
                "password" => Hash::make($request->password),
                "user_type"  => "Farmer"
            ]);
            Debugbar::info("User registered -". $user->id);

            //attempt login again now
            if(Auth::attempt(['mobile' => $request->mobile, 'password' => $request->password])){
                $user = $this->guard()->user();
                $user->generateToken();
    
                return response()->json([
                    'data' => $user->toArray(),
                ]);
            }
        }*/

        return $this->sendFailedLoginResponse($request);
    }

    //custome method
    protected function validateLogin(Request $request)
    {
        $this->validate($request, [
            'mobile'           => 'required|max:10',
            'password'         => 'required'//|confirmed',
        ]);
    }

    //custome method
    public function logout(Request $request)
    {
        $user = Auth::guard('api')->user();

        if ($user) {
            $user->api_token = null;
            $user->save();
        }

        return response()->json(['data' => 'User logged out.'], 200);
    }
}
