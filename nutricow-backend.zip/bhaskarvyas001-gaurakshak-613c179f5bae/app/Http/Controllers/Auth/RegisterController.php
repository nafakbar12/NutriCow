<?php

namespace App\Http\Controllers\Auth;

use App\User;
use App\Customer;
use App\Lookup;
use App\Plan;
use App\Address;
use App\Profile;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Http\Request;
use Illuminate\Auth\Events\Registered;
use DB;

class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = '/home';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'name' => ['required', 'string', 'max:255'],
            'mobile' => ['required', 'string', 'max:255', 'unique:users'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\User
     */
    protected function create(array $data)
    {
        return User::create([
            'name' => $data['name'],
            'mobile' => $data['mobile'],
            'password' => Hash::make($data['password']),
            'user_type' => $data['user_type'],
        ]);
    }

    //custome method
    public function register(Request $request)
    {
        // Here the request is validated. The validator method is located
        // inside the RegisterController, and makes sure the name, mobile
        // password and password_confirmation fields are required.
        $this->validator($request->all())->validate();

        // A Registered event is created and will trigger any relevant
        // observers, such as sending a confirmation mobile or any
        // code that needs to be run as soon as the user is created.
        event(new Registered($user = $this->create($request->all())));

        //send confirmation email
        //Mail::to($ser->email)->send(new ConfirmationEmail($user));
        //return back()->with('status','Please confirm your email address');

        // After the user is created, he's logged in.
        $this->guard()->login($user);

        // And finally this is the hook that we want. If there is no
        // registered() method or it returns null, redirect him to
        // some other URL. In our case, we just need to implement
        // that method to return the correct response.
        return $this->registered($request, $user)
                        ?: redirect($this->redirectPath());
    }

    //custome method
    protected function registered(Request $request, $user)
    {
        DB::beginTransaction();
        //once user is created make an entry in customer too
        /*$plan = plan::where('name', '=', 'Basic')->first();
        $b2c_customer_type = Lookup::where('value', '=', 'B2C')->first();*/
        $data = $request->all();
        $address = new Address(array(
            'name' => $data['name'],
            'location_type' => 'Farmer',
            'mobile' => $data['mobile'],
            'address' => ' ',
            'district_id' => $data['district_id'],
            'state_id' => $data['state_id'],
            'country_id' => 1 //by default 1 which is India
        ));
        $address->save();

        Profile::create([
            'user_id' => $user->id,
            'address_id' => $address->id
        ]);

        DB::commit();

        $user->generateToken();
        return response()->json(['data' => $user->toArray()], 201);
    }
}
