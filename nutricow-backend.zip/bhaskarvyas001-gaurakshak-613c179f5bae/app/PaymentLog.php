<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property integer $id
 * @property integer $from_user_id
 * @property integer $to_user_id
 * @property string $start_date
 * @property string $end_date
 * @property string $transaction_date
 * @property float $amount
 * @property string $transaction_id
 * @property float $balance
 * @property string $mode_of_transaction
 * @property string $transaction_details
 * @property string $created_at
 * @property string $updated_at
 * @property User $user
 * @property User $user
 */
class PaymentLog extends Model
{
    /**
     * The table associated with the model.
     * 
     * @var string
     */
    protected $table = 'paymentlog';

    /**
     * The "type" of the auto-incrementing ID.
     * 
     * @var string
     */
    protected $keyType = 'integer';

    /**
     * @var array
     */
    protected $fillable = ['from_user_id', 'to_user_id', 'start_date', 'end_date', 'transaction_date', 'amount', 'transaction_id', 'balance', 'mode_of_transaction', 'transaction_details', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function fromUser()
    {
        return $this->belongsTo('App\User', 'from_user_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function toUser()
    {
        return $this->belongsTo('App\User', 'to_user_id');
    }
}
