<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property integer $id
 * @property integer $category_id
 * @property integer $fodder_id
 * @property integer $state_id
 * @property float $dm
 * @property float $dcp
 * @property float $tdn
 * @property float $ca
 * @property float $p
 * @property float $cp
 * @property boolean $isdeleted
 * @property string $created_at
 * @property string $updated_at
 * @property NciCategory $nciCategory
 * @property NciFodder $nciFodder
 * @property State $state
 */
class NciNutricheck extends Model
{
    /**
     * The "type" of the auto-incrementing ID.
     * 
     * @var string
     */
    protected $keyType = 'integer';

    /**
     * @var array
     */
    protected $fillable = ['category_id', 'fodder_id', 'state_id', 'dm', 'dcp', 'tdn', 'ca', 'p', 'cp', 'isdeleted', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function nciCategory()
    {
        return $this->belongsTo('App\NciCategory', 'category_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function nciFodder()
    {
        return $this->belongsTo('App\NciFodder', 'fodder_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function state()
    {
        return $this->belongsTo('App\State');
    }
}
