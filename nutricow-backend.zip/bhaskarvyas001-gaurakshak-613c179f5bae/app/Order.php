<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property integer $id
 * @property integer $user_id
 * @property integer $referral_id
 * @property integer $address_id
 * @property int $quantity
 * @property float $total_cost
 * @property float $total_discount
 * @property float $total_tax
 * @property float $total_balance
 * @property string $created_at
 * @property string $updated_at
 * @property Address $address
 * @property User $user
 * @property User $user
 * @property Orderitem[] $orderitems
 * @property Orderpayment[] $orderpayments
 */
class Order extends Model
{
    /**
     * The "type" of the auto-incrementing ID.
     * 
     * @var string
     */
    protected $keyType = 'integer';

    /**
     * @var array
     */
    protected $fillable = ['user_id', 'referral_id', 'address_id', 'quantity', 'total_cost', 'total_discount', 'total_tax', 'total_balance', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function address()
    {
        return $this->belongsTo('App\Address');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function referralUser()
    {
        return $this->belongsTo('App\User', 'referral_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo('App\User');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function orderitems()
    {
        return $this->hasMany('App\Orderitem');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function orderpayments()
    {
        return $this->hasMany('App\Orderpayment');
    }
}
