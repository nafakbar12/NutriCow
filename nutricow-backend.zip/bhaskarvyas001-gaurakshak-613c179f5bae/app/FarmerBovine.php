<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property integer $id
 * @property integer $user_id
 * @property integer $bovine_id
 * @property string $biometric
 * @property string $bovine_profile
 * @property string $created_at
 * @property string $updated_at
 * @property Bovine $bovine
 * @property User $user
 * @property Producelog[] $producelogs
 */
class FarmerBovine extends Model
{
    /**
     * The table associated with the model.
     * 
     * @var string
     */
    protected $table = 'farmer_bovine';

    /**
     * The "type" of the auto-incrementing ID.
     * 
     * @var string
     */
    protected $keyType = 'integer';

    /**
     * @var array
     */
    protected $fillable = ['user_id', 'bovine_id', 'biometric', 'bovine_profile', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function bovine()
    {
        return $this->belongsTo('App\Bovine');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo('App\User');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function producelogs()
    {
        return $this->hasMany('App\Producelog', 'farmer_bovine_type_id');
    }
}
