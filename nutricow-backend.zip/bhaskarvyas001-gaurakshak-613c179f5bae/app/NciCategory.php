<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property integer $id
 * @property string $name
 * @property boolean $isvisible
 * @property string $created_at
 * @property string $updated_at
 * @property NciFodder[] $nciFodders
 * @property NciNutricheck[] $nciNutrichecks
 * @property NciSubcategory[] $nciSubcategorys
 */
class NciCategory extends Model
{
    /**
     * The table associated with the model.
     * 
     * @var string
     */
    protected $table = 'nci_categorys';

    /**
     * The "type" of the auto-incrementing ID.
     * 
     * @var string
     */
    protected $keyType = 'integer';

    /**
     * @var array
     */
    protected $fillable = ['name', 'isvisible', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function nciFodders()
    {
        return $this->hasMany('App\NciFodder', 'category_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function nciNutrichecks()
    {
        return $this->hasMany('App\NciNutricheck', 'category_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function nciSubcategorys()
    {
        return $this->hasMany('App\NciSubcategory', 'category_id');
    }
}
