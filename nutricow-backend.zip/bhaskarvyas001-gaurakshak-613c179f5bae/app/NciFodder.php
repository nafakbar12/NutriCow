<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property integer $id
 * @property integer $category_id
 * @property integer $subcategory_id
 * @property string $name
 * @property string $image
 * @property boolean $isvisible
 * @property string $created_at
 * @property string $updated_at
 * @property NciCategory $nciCategory
 * @property NciSubcategory $nciSubcategory
 * @property NciNutricheck[] $nciNutrichecks
 */
class NciFodder extends Model
{
    /**
     * The "type" of the auto-incrementing ID.
     * 
     * @var string
     */
    protected $keyType = 'integer';

    /**
     * @var array
     */
    protected $fillable = ['category_id', 'subcategory_id', 'name', 'image', 'isvisible', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function nciCategory()
    {
        return $this->belongsTo('App\NciCategory', 'category_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function nciSubcategory()
    {
        return $this->belongsTo('App\NciSubcategory', 'subcategory_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function nciNutrichecks()
    {
        return $this->hasMany('App\NciNutricheck', 'fodder_id');
    }
}
