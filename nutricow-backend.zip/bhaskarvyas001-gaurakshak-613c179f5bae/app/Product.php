<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property integer $id
 * @property string $name
 * @property string $type
 * @property string $description
 * @property string $image
 * @property float $price
 * @property float $discount
 * @property string $discount_type
 * @property string $other_details
 * @property string $created_at
 * @property string $updated_at
 * @property Orderitem[] $orderitems
 */
class Product extends Model
{
    /**
     * The "type" of the auto-incrementing ID.
     * 
     * @var string
     */
    protected $keyType = 'integer';

    /**
     * @var array
     */
    protected $fillable = ['name', 'type', 'description', 'image', 'price', 'discount', 'discount_type', 'other_details', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function orderitems()
    {
        return $this->hasMany('App\Orderitem');
    }
}
