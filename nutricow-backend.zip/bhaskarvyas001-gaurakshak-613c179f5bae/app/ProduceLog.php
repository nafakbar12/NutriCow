<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @property integer $id
 * @property integer $from_user_id
 * @property integer $to_user_id
 * @property integer $farmer_bovine_type_id
 * @property integer $bovine_id
 * @property string $transaction_date
 * @property float $quantity
 * @property float $fat
 * @property float $snf
 * @property string $created_at
 * @property string $updated_at
 * @property FarmerBovine $farmerBovine
 * @property User $user
 * @property User $user
 */
class ProduceLog extends Model
{
    /**
     * The table associated with the model.
     * 
     * @var string
     */
    protected $table = 'producelog';

    /**
     * The "type" of the auto-incrementing ID.
     * 
     * @var string
     */
    protected $keyType = 'integer';

    /**
     * @var array
     */
    protected $fillable = ['from_user_id', 'to_user_id', 'farmer_bovine_type_id', 'bovine_id', 'transaction_date', 'quantity', 'fat', 'snf', 'created_at', 'updated_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function farmerBovine()
    {
        return $this->belongsTo('App\FarmerBovine', 'farmer_bovine_type_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function fromUser()
    {
        return $this->belongsTo('App\User', 'from_user_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function toUser()
    {
        return $this->belongsTo('App\User', 'to_user_id');
    }
}
