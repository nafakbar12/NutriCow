# For Deployment in Production do this
1. install laravel using cloudways application creation process
2. it will install laravel 9 which is ok
3. Update the .env and .env.prod files in the local with the DB details from cloudways server
4. Then copy paste all files in public_html folder
5. copy all files from public folder in public_html folder
5. open the website URL
6. Delete the file "/public_html/config/sanctum.php". NOTE: This is there only on server and not in local worskspace as it comes with laravel 9.
7. Change the php version in cloudways to 7.4
9. enable https redirection and SSL. non https url creates problem
8. Your API should work now

### Refrence: https://medium.com/laravel-news/the-simple-guide-to-deploy-laravel-5-application-on-shared-hosting-1a8d0aee923e

# For Loggers and Debuggers
1. Install following plugins
    * https://github.com/rap2hpoutre/laravel-log-viewer
    * https://github.com/barryvdh/laravel-debugbar
2. Follow instructions at following website - https://medium.com/employbl/debugging-and-development-tools-for-laravel-5-5-ab3b48b871f4
3. Install *Clockwork* chrome extension where you can see the Laravel API query details like Time take, DB queries called and Debugger logs
4. Open the URL *http://127.0.0.1:8000/logs* to view the logs


# Running console Command from terminal
php artisan command:vendorPincodeSync

# generate models from DB table
https://github.com/krlove/eloquent-model-generator/tree/1x
# fix error with the model generator
https://stackoverflow.com/questions/33817983/artisan-migration-error-class-doctrine-dbal-driver-pdomysql-driver-not-fo


