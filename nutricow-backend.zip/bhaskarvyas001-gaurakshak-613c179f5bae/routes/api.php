<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::post('register', 'Auth\RegisterController@register');
Route::post('login', 'Auth\LoginController@login');
Route::post('register', 'Auth\RegisterController@register');
Route::post('logout', 'Auth\LoginController@logout');
Route::get('regdistricts', 'DistrictController@index');
Route::get('regstates', 'StateController@index');

Route::group(['middleware' => 'auth:api'], function() {
    Route::resource('addresses', 'AddressController', ['only' => ['index', 'show', 'store', 'update']]);
    Route::resource('bovines', 'BovineController', ['only' => ['index', 'show', 'store', 'update']]);
    Route::resource('countries', 'CountryController', ['only' => ['index', 'show', 'store', 'update']]);
    Route::resource('districts', 'DistrictController', ['only' => ['index', 'show', 'store', 'update']]);
    Route::resource('farmerbovines', 'FarmerBovineController', ['only' => ['index', 'show', 'store', 'update']]);
    Route::resource('producelogss', 'FarmerProduceLogController', ['only' => ['index', 'show', 'store', 'update']]);
    Route::resource('paymentlogs', 'PaymentLogController', ['only' => ['index', 'show', 'store', 'update']]);
    Route::resource('profiles', 'ProfileController', ['only' => ['index', 'show', 'store', 'update']]);
    Route::resource('states', 'StateController', ['only' => ['index', 'show', 'store', 'update']]);
    Route::resource('users', 'UserController', ['only' => ['index', 'show', 'store', 'update']]);
    Route::resource('villages', 'VillageController', ['only' => ['index', 'show', 'store', 'update']]);
    Route::resource('zones', 'ZoneController', ['only' => ['index', 'show', 'store', 'update']]);
    Route::resource('products', 'ProductController', ['only' => ['index', 'show', 'store', 'update']]);
    Route::resource('orders', 'OrderController', ['only' => ['index', 'show', 'store', 'update']]);
    Route::resource('orderpayments', 'OrderPaymentController', ['only' => ['index', 'show', 'store', 'update']]);
    Route::resource('ncicategories', 'NciCategoryController', ['only' => ['index', 'show', 'store', 'update']]);
    Route::resource('ncisubcategories', 'NciSubcategoryController', ['only' => ['index', 'show', 'store', 'update']]);
    Route::resource('ncifodders', 'NciFodderController', ['only' => ['index', 'show', 'store', 'update']]);
    Route::resource('ncirecommendations', 'NciRecommendedController', ['only' => ['index', 'show', 'store', 'update']]);
    Route::resource('ncinutrichecks', 'NciNutricheckController', ['only' => ['index', 'show', 'store', 'update']]);

    Route::post('nutricheck', 'NciNutricheckController@nutricheck');
    Route::post('nutrirecommend', 'NciRecommendedController@nutrirecommend');
    Route::post('speechtotext', 'NciNutricheckController@watsonSpeechtoText');
});
