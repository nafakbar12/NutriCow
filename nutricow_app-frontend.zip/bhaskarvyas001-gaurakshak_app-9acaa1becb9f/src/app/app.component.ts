import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { Platform } from '@ionic/angular';
import { UserService } from './api/user.service';
import Utils from './api/utils';
import { Storage } from '@ionic/storage';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  public appPages = [
    {title: 'Home', url: '/home', icon: 'home'},
    {title: 'Nutricheck', url: '/nutricheck', icon: 'leaf'},
    { title: 'Shop', url: '/shop', icon: 'book' },
    { title: 'Orders', url: '/order', icon: 'person' },
    { title: 'Videos', url: '/video', icon: 'search' },
    //{ title: 'Msg Branch', url: '/branch', icon: 'mail' },
  ];
  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    private userService: UserService,
    private router: Router,
    private storage: Storage    
  ) {
    this.initializeApp();
  }

  logout(){
    this.storage.set('villages', []);
    this.storage.set('zones', []);
    this.storage.set('districts', []);
    this.storage.set('states', []);
    this.storage.set('countries', []);
    this.storage.set('bovines', []);
    this.storage.set('products', []);
    this.storage.set('categories', []);
    this.storage.set('subcategories', []);
    this.storage.set('fodders', []);
    this.router.navigate(['/logout']);
    Utils.showMessage('success', 'Logged out successfully');

    this.userService.logout().subscribe(()=>{
      //not doing anything as of now
      //it just clears the token at server
    },()=>{
      //Utils.showMessage('danger', 'Failed to logout.');
      console.log('Failed to logout from server');
    });
  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
  }
}
