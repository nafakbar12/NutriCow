import { Component, OnInit, NgZone } from '@angular/core';
import { Geolocation } from '@ionic-native/geolocation/ngx';
import { BovineService } from 'src/app/api/bovine.service';
import { Router } from '@angular/router';
import { StaticService } from 'src/app/api/static.service';
import { UserService } from 'src/app/api/user.service';
import { Fodder } from 'src/app/models/fodder';
import { Category } from 'src/app/models/category';
import { Platform } from '@ionic/angular';
import { File, FileEntry, FileError } from '@ionic-native/file/ngx';
import { Media, MediaObject } from '@ionic-native/media/ngx';
import Utils from 'src/app/api/utils';
import { AudioInput, AudioInputConfiguration }  from 'cordova-plugin-audioinput';
declare var audioinput: AudioInput;

@Component({
  selector: 'app-nutricheck',
  templateUrl: './nutricheck.component.html',
  styleUrls: ['./nutricheck.component.scss'],
})
export class NutricheckComponent implements OnInit {

  private cowPic = {src: "assets/cow.PNG"};
  private buffalowPic = {src: "assets/bufallow.PNG"};
  private optionSelected = 'none'; //current or recommended
  private bovineSelected = null;
  private foddersSelected: Fodder[] = [];
  private details = {milkperday: null, weightofbovine: null};
  private categories: Category[] = [];
  private selectedCategories: Category[] = [];
  private fodders: Fodder[] = [];
  private fodderWeightDone = false;
  private userType: string;
  private nutriCheck: any = {dm: 0, tdn:0, cal:0, dcp:0, p:0, recommendations:{dm: 0, tdn:0, ca:0, dcp:0, p:0}};
  private nutriRecommend: any = {green_fodder:0, dry_fodder: 0, concentrate: 0, salt: 0, yeast: 0, molasses: 0};
  private recommendationsShow = false;
  private nutriGiven: any = {green_fodder:0, dry_fodder: 0, concentrate: 0, salt: 0, yeast: 0, molasses: 0};
  private filePaths: string;
  private fileExtension: string;
  private fileName: string;
  private audio: MediaObject ;
  private audioFile: FileEntry;
  private isMilkRecording: boolean = false;
  private isWeightRecording: boolean = false;
  private audioCfg: AudioInputConfiguration;

  constructor(private geolocation: Geolocation, private bovineService: BovineService, 
    private router: Router, private staticService: StaticService, private userService: UserService,
    private platform: Platform, private media: Media, private file: File,
    private ngZone: NgZone) {
      //initialize audio input
      this.platform.ready().then(() => {
        let fileUrl = null;
        if(this.platform.is("ios")){
          fileUrl = this.file.tempDirectory;
        } else {
          fileUrl = this.file.dataDirectory;
        }

        // Now you can initialize audio, telling it about the file system you want to use.
        this.audioCfg = {
          sampleRate: audioinput.SAMPLERATE.CD_AUDIO_44100Hz,
          channels: audioinput.CHANNELS.STEREO,
          format: audioinput.FORMAT.PCM_16BIT,
          bufferSize: 4096,
          fileUrl: fileUrl
        }
        // Initialize the audioinput plugin.
        audioinput.initialize(this.audioCfg, function() {	
          // Now check whether we already have permission to access the microphone.
          audioinput.checkMicrophonePermission(function(hasPermission) {
              if (hasPermission) {
                console.log("Already have permission to record.");
              } 
              else {	        
                // Ask the user for permission to access the microphone
                audioinput.getMicrophonePermission(function(hasPermission, message) {
                    if (hasPermission) {
                      console.log("User granted permission to record.");
                    } else {
                      console.warn("User denied permission to record.");
                    }
                });
              }
          });
        });
      });
    }

  ngOnInit() {
    this.clearCache();
    //this.fodders = this.bovineService.fodders;
    //if(this.fodders && this.fodders.length == 0){
      this.bovineService.getFodders().subscribe((fodders)=>{
        this.fodders = fodders;
        this.fodders.map(obj => ({ ...obj, selected: false }))
        this.fodders.map(obj => ({ ...obj, quantity: 0 }))
      })
      /*this.fodders = this.fodders.map((c, i) => {
        return { ...this.fodders[i], quantity: 0 };
      });      
    }else{
      if(this.fodders){
        this.fodders = this.fodders.map((c, i) => {
          return { ...this.fodders[i], selected: false };
        });
        this.fodders = this.fodders.map((c, i) => {
          return { ...this.fodders[i], quantity: 0 };
        });
      }
    }*/
    //this.categories = this.bovineService.categories;
    //if(this.categories && this.categories.length == 0){
      this.bovineService.getCategories().subscribe((categories)=>{
        this.categories = categories;
      })
    //}    
    /*if(this.staticService.bovines.length == 0 || this.staticService.villages.length == 0 || this.staticService.zones.length == 0 || 
      this.staticService.districts.length == 0 || this.staticService.states.length == 0 || this.staticService.countries.length == 0){
        this.staticService.loadAllStaticData();
    }*/

    let self = this;
    self.userType = (self.userService && self.userService.user) ? self.userService.user.user_type : null;
    if(!self.userType){
      self.router.navigate(['/login']);
    }
  }

  nutricheck(option){
    this.optionSelected = option;
  }

  selectBovine(bovineType){
    this.bovineSelected = bovineType;
  }

  fodderSelection(operation){
    if(operation == 'submit'){
      this.foddersSelected = this.fodders.filter(obj => obj.selected);
      this.foddersSelected.map(obj => ({ ...obj, quantity: 0 }))
      let selCats = this.foddersSelected.map(a => a.category_id);
      this.categories.forEach(element => {
        if(selCats.indexOf(element.id) >= 0){
          this.selectedCategories.push(element);
        }
      });
      console.log(this.foddersSelected);
    }

    if(operation == 'back'){
      this.bovineSelected = null;
      this.foddersSelected = [];
    }
  }

  fodderWeighEntry(operation){
    if(operation == 'submit'){
      let payload = {
        bovine_type: this.bovineSelected == 'cow' ? 1 : 2, //different from recommend as per our DB value
        ismilking: 1, //different from recommend as per our DB value
        milk_yield: this.details.milkperday,
        bovine_weight: this.details.weightofbovine,
        foddersSelected: this.foddersSelected
      }
      console.log(this.foddersSelected);
      this.fodderWeightDone = true;
      if(this.optionSelected != 'current'){
        this.recommendations();
      }else{
        //get the nutricheck call
        this.bovineService.nutricheck(payload).subscribe(result=>{
          this.nutriCheck = result;
        })
      }
    }

    if(operation == 'back'){
      this.fodderWeightDone = false;
      this.fodders = this.fodders.map((c, i) => {
        return { ...this.fodders[i], quantity: 0 };
      });
      this.foddersSelected = [];
      this.selectedCategories = [];
    }
  }

  filteredFodder(category){
    return this.fodders.filter(v => v.category_id === category.id)
  }

  filteredSelectedFodder(category){
    return this.foddersSelected.filter(v => v.category_id === category.id)
  }

  Shopping(productType){
    if(productType == 'back'){
      //hide nutricheck
      this.fodderWeightDone = false;
      this.nutriCheck = {dm: 0, tdn:0, cal:0, dcp:0, p:0, recommendations:{dm: 0, tdn:0, ca:0, dcp:0, p:0}};
      //hide recommendations
      this.recommendationsShow = false;
      this.nutriRecommend = {green_fodder:0, dry_fodder: 0, concentrate: 0, salt: 0, yeast: 0, molasses: 0};
      this.nutriGiven = {green_fodder:0, dry_fodder: 0, concentrate: 0, salt: 0, yeast: 0, molasses: 0};
    }else if(productType == 'recommendback'){
      this.recommendationsShow = false;
      this.nutriRecommend = {green_fodder:0, dry_fodder: 0, concentrate: 0, salt: 0, yeast: 0, molasses: 0};
      this.nutriGiven = {green_fodder:0, dry_fodder: 0, concentrate: 0, salt: 0, yeast: 0, molasses: 0};
    }else if(productType == 'home'){
      this.clearCache();
      //location.href = '/home';
      this.router.navigate(['/home']);
    }else{
      let params = { queryParams: {type: this.userType, productType: productType}};
      this.clearCache();
      this.router.navigate(['/shop'], params);
    }
  }

  recommendations(){
    this.recommendationsShow = true;
    let request = {
      bovine_weight: this.details.weightofbovine,
      milk_yield: this.details.milkperday,
      bovine_type: this.bovineSelected == 'cow' ? 2 : 1,
      milking: 2
    }

    this.foddersSelected.forEach((element: Fodder) => {
      if(element.category_id == 1){
        this.nutriGiven.green_fodder += element['quantity'];
      }
      if(element.category_id == 2){
        this.nutriGiven.dry_fodder += element['quantity'];
      }
      if(element.category_id == 3){
        this.nutriGiven.concentrate += element['quantity'];
      }
      if(element.category_id == 4 && element.name == 'Salt'){
        this.nutriGiven.salt += element['quantity'];
      }
      if(element.category_id == 4 && element.name == 'Yeast Powder'){
        this.nutriGiven.yeast += element['quantity'];
      }
      if(element.category_id == 4 && element.name == 'Molasses'){
        this.nutriGiven.molasses += element['quantity'];
      }
    });

    this.bovineService.nutrirecommend(request).subscribe(response => {
      this.nutriRecommend = response;
    })
  }


  async record(type){
    if(type == 'weight' && this.isMilkRecording){
      this.isMilkRecording = !this.isMilkRecording;
      if(audioinput.isCapturing){
        audioinput.stop(function(fileurl) {
          console.log("Stopped recording. Do nothing");
          //this.sendFileToProcess('milk', fileurl);
        });
      }
    }else if(type == 'milk' && this.isWeightRecording){
      this.isWeightRecording = !this.isWeightRecording;
      if(audioinput.isCapturing){
        audioinput.stop(function(fileurl) {
          console.log("Stopped recording. Do nothing");
          //this.sendFileToProcess('milk', fileurl);
        });
      }
    }

    if(type == 'milk'){
      if(this.isMilkRecording){
        console.log("Stoping record");
        let self = this;
        if(audioinput.isCapturing){
          audioinput.stop(function(fileurl) {
            console.log("Stopped recording. Sending file: "+fileurl);
            self.sendFileToProcess('milk');
          });
        }
      }else{
        this.startRecording();
      }
      this.isMilkRecording = !this.isMilkRecording;
    }

    if(type == 'weight'){
      if(this.isWeightRecording){
        console.log("Stoping record");
        let self = this;
        if(audioinput.isCapturing){
          audioinput.stop(function(fileurl) {
            console.log("Stopped recording. Sending file: "+fileurl);
            self.sendFileToProcess('weight');
          });
        }
      }else{
        this.startRecording();
      }      
      this.isWeightRecording = !this.isWeightRecording;
    }
  }

  async startRecording(){
    console.log("Start record");
    let fileUrl = null;
    if(this.platform.is("ios")){
      this.filePaths = this.file.tempDirectory;
      this.fileName = new Date().getTime() + ".m4a";
      this.audioFile = await this.file.createFile(this.filePaths, this.fileName, true);
      if(this.file.tempDirectory){
        fileUrl = this.file.tempDirectory.replace(/^file:\/\//, '') + this.fileName
      }
    } else {
      this.filePaths = this.file.dataDirectory;
      this.fileName = new Date().getTime() + ".wav";
      this.audioFile = await this.file.createFile(this.filePaths, this.fileName, true);
      //this.audioMediaSrc = this.audioFile.nativeURL.replace(/^file:[\/]+/, '');
      fileUrl = this.audioFile.nativeURL
    }
    
    var captureCfg = {
      fileUrl : fileUrl
    }
  
    audioinput.start( captureCfg );
  }

  async sendFileToProcess(type){
    try {
      console.log("In sendFileToProcess");
      // It requires a little delay to get media file data
      await this.delay(5000);
      let blob;
      console.log(this.audioFile.nativeURL);
      console.log(this.audioFile.fullPath);
      console.log("Is file: " + this.audioFile.isFile);
      let self = this;
      this.audioFile.file(async function(file){
        console.log("getting getBlobFromFile");
        blob = await self.getBlobFromFile(file);
        console.log("back from getBlobFromFile");

        // SAVE AUDIO HERE!
        // A Blob() is almost a File() - it's just missing the two properties below which we will add
        // tslint:disable-next-line: no-string-literal
        blob['lastModifiedDate'] = new Date();
        // tslint:disable-next-line: no-string-literal
        blob['name'] = self.fileName;
        //const formData = new FormData();
        //formData.append('file', blob as Blob, this.fileName);  
        //upload here

        //Utils.showMessage('success', blob);
        console.log("got blob; making API call. Filename: " + self.fileName);
        self.bovineService.uploadSpeechFile(blob, self.fileName).subscribe(resp=>{
          console.log("Response from server:"+resp);
          //Utils.showMessage('success', resp);
          self.ngZone.run(() => {
            if(type == 'milk'){
              self.details.milkperday = resp;
            }else{
              self.details.weightofbovine = resp;
            }
          })
        })
      }, function(err: FileError){
        console.log("Error while reading file: "+JSON.stringify(err));
      })
    }catch(err){
      Utils.showMessage('danger', err.message);
    } finally {
      //console.log("Closing audiofile");
      //this.audioFile = null;
    }
  }

  getBlobFromFile(file: any): Promise<Blob> {
    console.log("in getBlobFromFile");
    let self = this;
    return new Promise((resolve, reject) => {
      let fileReader = self.getFileReader();

      fileReader.onloadend = function() {
        console.log("file opened: " + this.result);
        var blob = new Blob([this.result], { type: "audio/wav" })
        console.log("resolving get blob");
        resolve(blob);
      };

      fileReader.onerror = function(err) {
        console.log("Error getting blob: "+err);
        reject(err);
      };

      fileReader.readAsArrayBuffer(file);
    });
  }

  getFileReader(): FileReader {
    console.log("in getFileReader");
    const fileReader = new FileReader();
    const zoneOriginalInstance = (fileReader as any)["__zone_symbol__originalInstance"];
    return zoneOriginalInstance || fileReader;
  }

  delay(time: number){
    new Promise<void>(resolve => setTimeout(() => resolve(), time))
  }

  clearCache(){
    this.optionSelected = 'none';
    this.bovineSelected = null;
    this.foddersSelected = [];
    this.details = {milkperday: null, weightofbovine: null};
    this.selectedCategories = [];
    this.fodders.map(obj => ({ ...obj, selected: false }))
    this.fodders = this.fodders.map((c, i) => {
      return { ...this.fodders[i], selected: false };
    });
    this.fodders = this.fodders.map((c, i) => {
      return { ...this.fodders[i], quantity: 0 };
    });    
    this.fodderWeightDone = false;
    this.userType = null;
    this.nutriCheck = {dm: 0, tdn:0, cal:0, dcp:0, p:0, recommendations:{dm: 0, tdn:0, ca:0, dcp:0, p:0}};
    this.nutriRecommend = {green_fodder:0, dry_fodder: 0, concentrate: 0, salt: 0, yeast: 0, molasses: 0};
    this.recommendationsShow = false;
    this.nutriGiven = {green_fodder:0, dry_fodder: 0, concentrate: 0, salt: 0, yeast: 0, molasses: 0};    
  }
}
