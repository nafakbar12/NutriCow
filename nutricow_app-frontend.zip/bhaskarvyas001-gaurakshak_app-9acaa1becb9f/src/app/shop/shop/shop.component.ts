import { Component, OnInit } from '@angular/core';
import { Geolocation } from '@ionic-native/geolocation/ngx';
import { OrderService } from 'src/app/api/order.service';
import { Product } from 'src/app/models/product';
import { OrderItem } from 'src/app/models/orderItem';
import { ActivatedRoute, Router } from '@angular/router';
import { Address } from 'src/app/models/address';
import { StaticService } from 'src/app/api/static.service';
import { Order } from 'src/app/models/order';
import Utils from 'src/app/api/utils';
import { UserService } from 'src/app/api/user.service';

@Component({
  selector: 'app-shop',
  templateUrl: './shop.component.html',
  styleUrls: ['./shop.component.scss'],
})
export class ShopComponent implements OnInit {

  public products: Product[] = [];
  public starCheckout = false;
  public address: Address = null;
  public productType;

  constructor(private geolocation: Geolocation, private orderService: OrderService, 
    private router: Router, private staticService: StaticService, private userService: UserService,
    private activatedRoute: ActivatedRoute) {
      this.activatedRoute.queryParams.subscribe(params => {
        this.productType = params['productType'];
      }); 
    }

  ngOnInit() {
    this.address = new Address();
    this.address.location_type = this.userService.user.user_type;
    //this.products = this.orderService.allproducts;
    if(this.products.length == 0){
      this.orderService.products(this.productType).subscribe((products)=>{
        this.products = products;
      })
    }
    if(this.staticService.bovines.length == 0 || this.staticService.villages.length == 0 || this.staticService.zones.length == 0 || 
      this.staticService.districts.length == 0 || this.staticService.states.length == 0 || this.staticService.countries.length == 0){
        this.staticService.loadAllStaticData();
    }
  }

  decrement(productId){
//find the item in the order items
    let item = this.orderService.order.order_items.find(i => i.product_id === productId);
    if(item && item.quantity > 1){
      item.quantity = item.quantity - 1;
      const index = this.orderService.order.order_items.findIndex(item => item.product_id == productId);
      this.orderService.order.order_items[index] = item;
      this.orderService.cartSize -=1;
    }else{
      //remove item from array
      const index = this.orderService.order.order_items.findIndex(item => item.product_id == productId);
      if(index >= 0){
        this.orderService.order.order_items.splice(index,1);
        this.orderService.cartSize -=1;
      }
    }
  }

  increment(productId){
    //find the item in the order items
    let item = this.orderService.order.order_items.find(i => i.product_id === productId);
    if(item){
      item.quantity = item.quantity + 1;
      const index = this.orderService.order.order_items.findIndex(item => item.product_id == productId);
      this.orderService.order.order_items[index] = item;
    }else{
      //add the item if not there
      let orderItem = new OrderItem();
      orderItem.product_id = productId;
      orderItem.quantity = 1;
      this.orderService.order.order_items.push(orderItem);
    }
    this.orderService.cartSize +=1;
  }

  checkout(){
    if(this.orderService.cartSize > 0){
      this.starCheckout = true;
    }
  }

  placeOrder(){
    if(!this.address.name || this.address.name.length == 0){
      Utils.showMessage('danger', 'Name is required');
      return
    }
    if(!this.address.address || this.address.address.length == 0){
      Utils.showMessage('danger', 'Address is required');
      return
    }
    if(!this.address.pincode || this.address.pincode.toString().length != 6){
      Utils.showMessage('danger', 'Pincode should be 6 digits');
      return
    }
    if(!this.address.mobile || this.address.mobile.toString().length != 10){
      Utils.showMessage('danger', 'Mobile number should be 10 digits');
      return
    }
    let postData = {
      order: this.orderService.order,
      address: this.address
    }
    this.orderService.saveOrder(postData).subscribe((response: any) => {
      let message = "Order created";
      if(!response.id){
        message = response.error;
      }
      Utils.showMessage(response.id ? 'success':'danger', message);
      if(response.id){
        this.orderService.clearOrder();
        this.starCheckout = false;
      }
    })
  }
}
