import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StorageService } from 'src/app/api/storage.service';
import { UserService } from 'src/app/api/user.service';
import Utils from 'src/app/api/utils';
import { WaybillService } from 'src/app/api/waybill.service';
import { User } from 'src/app/models/user';


@Component({
  selector: 'app-video',
  templateUrl: './video.component.html',
  styleUrls: ['./video.component.scss'],
})
export class VideoComponent implements OnInit {

  constructor(private router: Router, private userService: UserService, private waybillService: WaybillService, 
    private storageService: StorageService) {
  }

  ngOnInit() { 
    
  }
  
}
  

