import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StaticService } from 'src/app/api/static.service';
import { StorageService } from 'src/app/api/storage.service';
import { UserService } from 'src/app/api/user.service';
import Utils from 'src/app/api/utils';
import { WaybillService } from 'src/app/api/waybill.service';
import { User } from 'src/app/models/user';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss'],
})
export class RegisterComponent implements OnInit {
  public item = {src:"assets/icon/gaurakshak-logo.png"};
  public credentials = {user_type: 'Farmer', mobile: null, password: null, password_confirmation: null, name: null, district_id: null, state_id: null};

  constructor(private router: Router, private userService: UserService, private waybillService: WaybillService, 
    private storageService: StorageService, private staticService: StaticService) {
  }

  ngOnInit() { 
    if(this.userService.user){
      this.router.navigate(['/home']);
    }

    if(!this.staticService.districts || !this.staticService.states || this.staticService.districts.length == 0 || this.staticService.states.length == 0){
        this.staticService.loadRegisterData();
    }
  }

  register = function(){
    let hasError = false;
    if(this.credentials.mobile && this.credentials.mobile.length != 10){
      Utils.showMessage('danger', "Mobile number should be 10 digits");
      hasError = true;
    }
    if(this.credentials.password && this.credentials.password.length < 8){
      Utils.showMessage('danger', "Password should be min 8 characters");
      hasError = true;
    }
    if(this.credentials.password_confirmation && this.credentials.password_confirmation.length < 8){
      Utils.showMessage('danger', "Confirm Password should be min 8 characters");
      hasError = true;
    }
    if(this.credentials.password_confirmation != this.credentials.password){
      Utils.showMessage('danger', "Confirm Password and Password should be same");
      hasError = true;
    }
    if(!this.credentials.state_id || !this.credentials.district_id){
      Utils.showMessage('danger', "Distrinct and State must be selected");
      hasError = true;
    }
    
    if(!hasError){
      this.userService.register(this.credentials).subscribe((user : User)=>{
        this.userService.user = user;
        this.router.navigate(['/home']);
      });
    }
  }
  
}
  

