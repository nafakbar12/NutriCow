export  class  Profile {
    id: number;
    user_id: number;
    profile_image: string;
    profile_data:string;

    location_type:string;
    mobile: number;
    phone: number;
    email:string;
    address:string;
    pincode: number;
    village_id: number;
    zone_id: number;
    district_id: number;
    state_id: number;
    country_id: number;

    constructor(values: Object = {}) {
        Object.assign(this, values);
    }
}