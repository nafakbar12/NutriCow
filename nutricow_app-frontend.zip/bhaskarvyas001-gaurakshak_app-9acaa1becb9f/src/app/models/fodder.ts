import { Category } from "./category";
import { Subcategory } from "./subcategory";

export  class  Fodder {
    id: number;
    name: string;
    category_id: number;
    subcategory_id: number;
    image: string;
    isvisible: number;
    nci_category: Category;
    nci_subcategory: Subcategory;
    selected: false;
    
    constructor(values: Object = {}) {
        Object.assign(this, values);
    }
}