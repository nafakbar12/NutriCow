import { OrderItem } from "./orderItem";

export  class  Order {
    id: number;
    user_id: number;
    referral_id: number;
    address_id: number;
    quantity: number;
    cost: number;
    tax: number;
    discount: number;
    order_items: OrderItem[];
    
    constructor(values: Object = {}) {
        Object.assign(this, values);
    }
}