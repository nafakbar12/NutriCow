export  class  Category {
    id: number;
    name: string;
    isvisible: number;
    
    constructor(values: Object = {}) {
        Object.assign(this, values);
    }
}