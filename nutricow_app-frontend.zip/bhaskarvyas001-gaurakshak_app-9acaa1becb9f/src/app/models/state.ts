export  class  State {
    id: number;
    name: string;
    country_id: number;
    
    constructor(values: Object = {}) {
        Object.assign(this, values);
    }
}