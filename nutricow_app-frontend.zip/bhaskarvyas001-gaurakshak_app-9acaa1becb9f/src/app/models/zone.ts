export  class  Zone {
    id: number;
    name: string;
    district_id: number;
    
    constructor(values: Object = {}) {
        Object.assign(this, values);
    }
}