import { Bovine } from "./bovine";
import { Profile } from "./profile";

export  class  Farmer {
    id: number;
    name: string;
    email: string;
    mobile: number;
    user_type:string;
    api_token: string;
    profile: Profile;
    bovine: Bovine;
    
    constructor(values: Object = {}) {
        Object.assign(this, values);
    }
}