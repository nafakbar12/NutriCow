export  class  OrderItem {
    product_id: number;
    quantity: number;
    
    constructor(values: Object = {}) {
        Object.assign(this, values);
    }
}