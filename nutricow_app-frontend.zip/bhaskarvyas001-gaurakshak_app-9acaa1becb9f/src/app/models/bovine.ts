export  class  Bovine {
    id: number;
    type: string;
    breed: string;
    biometric: string;
    bovine_profile: string;
    
    constructor(values: Object = {}) {
        Object.assign(this, values);
    }
}