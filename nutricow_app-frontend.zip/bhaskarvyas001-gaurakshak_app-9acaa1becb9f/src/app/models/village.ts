export  class  Village {
    id: number;
    name: string;
    zone_id: number;
    pincode: number;
    
    constructor(values: Object = {}) {
        Object.assign(this, values);
    }
}