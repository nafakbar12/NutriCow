export  class  Product {
    id: number;
    name: string;
    type: string;
    description: string;
    image: string;
    price: number;
    
    constructor(values: Object = {}) {
        Object.assign(this, values);
    }
}