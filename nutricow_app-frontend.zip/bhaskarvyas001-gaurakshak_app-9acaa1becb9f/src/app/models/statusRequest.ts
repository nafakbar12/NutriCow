
export  class  StatusRequest {
    branch_id: number;
    dstatus: string;
    rstatus: string;
    ndrid: string;
    ndrdate: string;
    delivPersonId: number;
    orders: string[];
    user: string;
    latitude: number;
    longitude: number;
    receiver_name: string;
    receiver_number: string;
    sku: string;
    quantity: string;
    ndrFileName: string;
    signatureFileName: string;

    constructor(values: Object = {}) {
        Object.assign(this, values);
    }
}