import { Profile } from "./profile";

export  class  User {
    id: number;
    name: string;
    email: string;
    mobile: number;
    user_type:string;
    api_token: string;
    profile: Profile;
    
    constructor(values: Object = {}) {
        Object.assign(this, values);
    }
}