export  class  Address {
    id: number;
    location_type:string;
    name: string;
    mobile: number;
    phone: number;
    email:string;
    address:string;
    pincode: number;
    village_id: number;
    zone_id: number;
    district_id: number;
    state_id: number;
    country_id: number;

    constructor(values: Object = {}) {
        Object.assign(this, values);
    }
}