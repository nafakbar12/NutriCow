export  class  Ndr {
    id: number;
    reason: string;

    constructor(values: Object = {}) {
        Object.assign(this, values);
    }
}