export  class  District {
    id: number;
    name: string;
    state_id: number;
    
    constructor(values: Object = {}) {
        Object.assign(this, values);
    }
}