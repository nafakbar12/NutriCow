export  class  Waybill {
    customer_id: number;
    booking_date: string;
    awb: string;
    remit_date: string;
    collectable_value: number;
    declared_value: number;
    weight: number;
    freight_charge: number;
    cod_charge: number;
    doc_charge: number;
    pos_charge: number;
    status: string;
    mode: string;
    origin: string;
    destination_id: number;
    dealer: string;
    invoice_no: number;
    branch_id: number;
    delivery_date: string;
    delivery_time: string;
    ndr_id: number;
    ndr_date: string;
    cust_id_proof: string;
    order_type: string;
    remittance_method: string;
    address: string;
    mobile: string;
    pin: number;
    deliv_person: string;
    run_date: string;
    remrk: string;
    sku_code: string;
    cust_remark: string;
    expected_date: string;
    quantity: number;
    vendor_id: number;
    age: number;

    constructor(values: Object = {}) {
        Object.assign(this, values);
    }
}