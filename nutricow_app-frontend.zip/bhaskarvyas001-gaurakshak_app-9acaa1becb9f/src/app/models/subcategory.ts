export  class  Subcategory {
    id: number;
    name: string;
    category_id: number;
    isvisible: number;
    
    constructor(values: Object = {}) {
        Object.assign(this, values);
    }
}