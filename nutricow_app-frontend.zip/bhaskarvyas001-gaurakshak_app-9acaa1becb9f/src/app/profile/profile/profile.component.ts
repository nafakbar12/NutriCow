import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/api/user.service';
import { WaybillService } from 'src/app/api/waybill.service';
import { Waybill } from 'src/app/models/waybill';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss'],
})
export class ProfileComponent implements OnInit {
  public profile = {src: "assets/icon/user.png"};
  public summary = {ofd: 0, ofp: 0, deliveryDone: 0, undelivered: 0, pickupDone: 0, perDelivery: 0, perPickup: 0, performance: 0};

  constructor(public userService: UserService, private waybillService: WaybillService) { }

  ngOnInit() {
    let drs = this.waybillService.drs;
    if(drs){
      this.summary.ofp = this.waybillService.drs.filter(function (waybill: Waybill) {
        return waybill.status === "OUT FOR PICKUP";
      }).length;

      this.summary.pickupDone = this.waybillService.drs.filter(function (waybill: Waybill) {
        return waybill.status === "Pickup Done";
      }).length;

      this.summary.deliveryDone = this.waybillService.drs.filter(function (waybill: Waybill) {
        return waybill.status === "DELIVERED";
      }).length;

      this.summary.undelivered = this.waybillService.drs.filter(function (waybill: Waybill) {
        return waybill.status === "UNDELIVERED";
      }).length;

      this.summary.ofd = this.waybillService.drs.filter(function (waybill: Waybill) {
        return waybill.status === "OUT FOR DELIVERY";
      }).length + this.summary.deliveryDone + this.summary.undelivered;

      this.summary.perDelivery =  parseFloat((this.summary.deliveryDone/this.summary.ofd * 100).toFixed(2));

      this.summary.perPickup = parseFloat((this.summary.pickupDone/this.summary.ofp * 100).toFixed(2));

      this.summary.performance = parseFloat(((this.summary.pickupDone+this.summary.deliveryDone)/( this.summary.ofd+ this.summary.ofp)*100).toFixed(2));

    }
  }
}
