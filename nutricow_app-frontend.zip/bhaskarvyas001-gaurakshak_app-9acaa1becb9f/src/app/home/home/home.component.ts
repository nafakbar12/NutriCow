import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/api/user.service';
import { StorageService } from 'src/app/api/storage.service';
import { Router } from '@angular/router';
import { StaticService } from 'src/app/api/static.service';
import Utils from 'src/app/api/utils';
 

@Component({  
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit {

  public userType: string = "Farmer";
  public profile = {src: "assets/farmer.png"};

  constructor(public userService: UserService, private storageService: StorageService, 
    private router: Router, private staticService: StaticService) {
      this.userType = (this.userService && this.userService.user) ? this.userService.user.user_type : null;
      if(!this.userType){
        this.router.navigate(['/login']);
      }
  }


  ngOnInit() {
    let self = this;
    self.userType = (self.userService && self.userService.user) ? self.userService.user.user_type : null;
    if(!self.userType){
      self.router.navigate(['/login']);
    }
  }

  onBoardUser(userType){
    this.router.navigate(['/onBoardUser'], { queryParams: {type: userType}});
  }

  shop(userType){
    this.router.navigate(['/shop'], { queryParams: {type: userType}});
  }

  videos(userType){
    this.router.navigate(['/video'], { queryParams: {type: userType}});
  }

  orders(userType){
    this.router.navigate(['/order'], { queryParams: {type: userType}});
  }

  nutricheck(userType){
    this.router.navigate(['/nutricheck'], { queryParams: {type: userType}});
  }

  history(userType){
    this.router.navigate(['/history'], { queryParams: {type: userType}});
  }
}
