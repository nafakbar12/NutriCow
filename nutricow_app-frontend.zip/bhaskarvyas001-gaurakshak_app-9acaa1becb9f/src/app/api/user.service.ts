import { Injectable } from '@angular/core';
import { HttpClient } from  '@angular/common/http';
import { Observable } from  'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import  'rxjs/add/operator/map';
import { User } from '../models/user';
import { Storage } from '@ionic/storage';
import Utils from './utils';
import { WaybillService } from './waybill.service';
import { StorageService } from './storage.service';
import { StaticService } from './static.service';
import { BovineService } from './bovine.service';
import { OrderService } from './order.service';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  public user: User = null;

  constructor(private  httpClient : HttpClient, private storage: Storage, 
    private waybillService: WaybillService, private storageService: StorageService,
    private staticService: StaticService, private bovineService: BovineService,
    private orderService: OrderService) {
    //load other data from local storage
    //Utils.showLoader();
    this.storageService.getUser().then((user: User)=>{
      Utils.dismissLoader()
      if(user){
        this.user = user;
      }
    },(error)=>{
      Utils.dismissLoader()
    })
  }

  public login(payload): Observable<User> {
    Utils.showLoader()
    return this.httpClient
    .post(Utils.baseUrl + 'login', payload)
    .map(response  => {
      Utils.dismissLoader()
      this.user = new  User(response['data']);
      this.storage.set('user', this.user);
      return  this.user;
    })
    .catch((err)=>{
      Utils.dismissLoader()
      Utils.showMessage('danger', err.message);
      return Observable.throw(err);
    });
  }

  public register(payload): Observable<User> {
    Utils.showLoader()
    return this.httpClient
    .post(Utils.baseUrl + 'register', payload)
    .map(response  => {
      Utils.dismissLoader()
      this.user = new  User(response['data']);
      this.storage.set('user', this.user);
      return  this.user;
    })
    .catch((err)=>{
      Utils.dismissLoader()
      Utils.showMessage('danger', err.message);
      return Observable.throw(err);
    });
  }

  public logout(): Observable<any> {
    return this.httpClient
    .post(Utils.baseUrl + 'logout', null)
    .map(response  => {
      this.user = null;
      this.storage.set('user', this.user);
      this.waybillService.clearStorageData();
      this.staticService.clearStorageData();
      this.orderService.clearStorageData();
      this.bovineService.clearStorageData();
      return response;
    })
    .catch((err)=>{
      Utils.showMessage('danger', err.message);
      return Observable.throw(err);
    });
  }

  public saveUser(payload:User): Observable<any> {
    Utils.showLoader()
    return this.httpClient
    .post(Utils.baseUrl + 'users', payload)
    .map(response  => {
      Utils.dismissLoader()
      return response;
    })
    .catch((err)=>{
      Utils.dismissLoader()
      Utils.showMessage('danger', err.message);
      return Observable.throw(err);
    });
  }
}
