import { Injectable } from '@angular/core';
import { HttpClient } from  '@angular/common/http';
import { Observable } from  'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import  'rxjs/add/operator/map';
import { Storage } from '@ionic/storage';
import Utils from './utils';
import { StorageService } from './storage.service';
import { Order } from '../models/order';
import { Product } from '../models/product';
import { UserService } from './user.service';

@Injectable({
  providedIn: 'root'
})
export class OrderService {
  public order: Order = new Order();
  public allproducts: Product[] = [];
  public cartSize: number = 0;

  constructor(private  httpClient : HttpClient, private storage: Storage, private orderServce: OrderService, 
    private storageService: StorageService, private userService: UserService) {
    this.order.order_items = [];
    this.order.user_id = this.userService.user?this.userService.user.id:null;
    //load other data from local storage
    //Utils.showLoader();
    this.storageService.getOrder().then((order: Order)=>{
      Utils.dismissLoader()
      if(order){
        this.order = order;
      }
    },(error)=>{
      Utils.dismissLoader()
    })

    this.storageService.getProduct().then((products: Product[])=>{
      Utils.dismissLoader()
      if(products){
        this.allproducts = products;
      }
    },(error)=>{
      Utils.dismissLoader()
    })
  }

  public clearOrder(){
    this.order = new Order();
    this.order.order_items = [];
    this.order.user_id = this.userService.user.id;
    this.cartSize = 0;
  }

  public getitemQtyInCart(productId){
    let item = this.order.order_items.find(i => i.product_id === productId);
    if(item)
      return item.quantity;
    else
      return 0;
  }

  public products(productType): Observable<Product[]> {
    Utils.showLoader()
    let urlPath = "products";
    if(productType){
      urlPath += "?productType="+productType;
    }
    return this.httpClient
    .get(Utils.baseUrl + urlPath)
    .map((response: Product[])  => {
      Utils.dismissLoader()
      this.allproducts = response;
      this.storage.set('products', this.allproducts);
      return  this.allproducts;
    })
    .catch((err)=>{
      Utils.dismissLoader()
      Utils.showMessage('danger', err.message);
      return Observable.throw(err);
    });
  }

  public saveOrder(payload: any): Observable<any> {
    Utils.showLoader()
    return this.httpClient
    .post(Utils.baseUrl + 'orders', payload)
    .map(response  => {
      Utils.dismissLoader()
      return response;
    })
    .catch((err)=>{
      Utils.dismissLoader()
      Utils.showMessage('danger', err.message);
      return Observable.throw(err);
    });
  }

  public orders(): Observable<any> {
    Utils.showLoader()
    return this.httpClient
    .get(Utils.baseUrl + 'orders')
    .map(response  => {
      Utils.dismissLoader()
      return response;
    })
    .catch((err)=>{
      Utils.dismissLoader()
      Utils.showMessage('danger', err.message);
      return Observable.throw(err);
    });
  }

  clearStorageData(){
    this.products = null;
    this.orders = null;
    this.storage.set('products', this.products);
    this.storage.set('orders', this.orders);
  }
}
