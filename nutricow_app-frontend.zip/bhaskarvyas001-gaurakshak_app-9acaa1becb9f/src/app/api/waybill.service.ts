import { Injectable } from '@angular/core';
import { HttpClient } from  '@angular/common/http';
import { Observable } from  'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import  'rxjs/add/operator/map';
import { Storage } from '@ionic/storage';
import Utils from './utils';
import { Geoposition } from '@ionic-native/geolocation/ngx';
import { StatusRequest } from '../models/statusRequest';
import { StorageService } from './storage.service';

@Injectable({
  providedIn: 'root'
})
export class WaybillService {
  public drs = null;
  public drsDate = null;
  public ndr = null;
  public sessionID = null;
  public sessionDate = null;

  constructor(private  httpClient : HttpClient, private storage: Storage, private storageService: StorageService) { 
    //load other data from local storage
    Utils.showLoader();
    this.storageService.getDrs().then((drs)=>{
      Utils.dismissLoader()
      if(drs){
        this.drs = drs;
      }
    },(error)=>{
      Utils.dismissLoader()
    })
  }

  getDRS(deliveryPerson_id: number){
    this.drs = null;
    this.storage.set('drs', this.drs);
    this.drsDate = null;
    this.storage.set('drsDate', this.drsDate);
    
    Utils.showLoader()
    return this.httpClient
    .get(Utils.baseUrl + 'services/orders/all?sort-by=booking_date&sort-order=asc&page=1&count=9999&deliv_person='+deliveryPerson_id+'&run_date='+Utils.dbtoday())
    .map(response  => {
      Utils.dismissLoader()
      this.drs = response['rows'];
      this.drsDate = Utils.dbtoday();
      this.storage.set('drs', this.drs);
      this.storage.set('drsDate', Utils.dbtoday());
      return response['rows'];
    })
    .catch((err)=>{
      Utils.dismissLoader()
      Utils.showMessage('danger', err.message);
      return Observable.throw(err);
    });
  }

  getNDR(){
    var ndrsToFilter = [15,39,91,120,42,155,19,26,45,46,14,78,103,140,30,77,74,70,81,100,75,44,106,94,34,227,20,102,217,56,69,132,310,32];
    return this.httpClient
    .get(Utils.baseUrl + 'services/ndr/all?status=active&sort-by=reason&sort-order=asc&page=1&count=9999')
    .map(response  => {
      this.ndr = response['rows'];
      //filter the ndrs that we need in teh app
      this.ndr = this.ndr.filter(function(ndrValue){ 
        return ndrsToFilter.indexOf(parseInt(ndrValue.id)) > -1
      })
      this.storage.set('ndr', this.ndr);
      return this.ndr;
    })
    .catch((err)=>{
      Utils.showMessage('danger', err.message);
      return Observable.throw(err);
    });
  }

  saveGpsLocaton(location: Geoposition, contact_no: number, name: string){
    //gps data
    let loc = location.coords;
    let lastUpdate = Utils.timestamp();
    let latitude = loc.latitude;
    let longitude = loc.longitude;
    let phoneNumber = contact_no;
    let userName = name;
    let sessionID = this.sessionID; //Utils.createUUID();
    let speed = loc.speed * 2.2369
    let direction = loc.heading;
    let distance = "0.0";
    let gpsTime = Utils.timestamp();
    let locationMethod = null;
    let accuracy = loc.accuracy * 3.28
    let extraInfo = "";
    let eventType = "android";

    return this.httpClient
    .get(Utils.baseUrl + 'tracker/updatelocation.php?lastUpdate='+lastUpdate+'&latitude='+latitude+'&longitude='+longitude
      +'&phonenumber='+phoneNumber+'&username='+userName+'&sessionid='+sessionID+'&speed='+speed+'&direction='+direction
      +'&distance='+distance+'&date='+gpsTime+'&locationmethod='+locationMethod+'&accuracy='+accuracy
      +'&extrainfo='+extraInfo+'&eventtype='+eventType)
    .map(response  => {
      return response;
    })
    .catch((err)=>{
      Utils.showMessage('danger', err.message);
      return Observable.throw(err);
    });
  }

  updateStatus(payload: StatusRequest): Observable<any>{
    Utils.showLoader()
    return this.httpClient
    .post(Utils.baseUrl + 'services/appUpdateStatus', payload)
    .map(response  => {
      Utils.dismissLoader()
      return response;
    })
    .catch((err)=>{
      Utils.dismissLoader()
      Utils.showMessage('danger', err.message);
      return Observable.throw(err);
    });
  }

  updateWaybillinList(awb: string, status: string){
    var foundIndex = this.drs.findIndex(x => x.awb == awb);
    this.drs[foundIndex].status = status;
    //update storage
    this.storage.set('drs', this.drs);
  }

  clearStorageData(){
    this.drs = null;
    this.drsDate = null;
    this.ndr = null;
    this.storage.set('drs', this.drs);
    this.storage.set('drsDate', this.drsDate);
    this.storage.set('ndr', this.ndr);
  }

  uploadSignature(dataURI: string, awb: string){
    let url = "phps/upload-page.php";
    let fileBlob = Utils.dataURLtoBlob(dataURI);
    let fileName = awb+'_'+Utils.dbtoday()+'.png';

    let formData: FormData = new FormData();
    formData.append('userfile[]', fileBlob, fileName);
    formData.append('uploadType', 'signatureProof');
    formData.append('awb', awb);


    return this.httpClient
    .post(Utils.baseUrl + url, formData)
    .map(response  => {
      //Utils.dismissLoader()
      return response;
    })
    .catch((err)=>{
      //Utils.dismissLoader()
      Utils.showMessage('danger', err.message);
      return Observable.throw(err);
    });

    //params.put("userfile[]", new DataPart(imagename + ".jpg", getFileDataFromDrawable(bitmap)));
    //params.put("uploadType", "signatureProof");
    //params.put("tags", "Upload_Signature_Image");
  }

  getSessionID(){
    this.sessionID = null;
    this.storage.set('sessionID', this.sessionID);
    this.sessionDate = null;
    this.storage.set('sessionDate', this.sessionDate);
    
    let sessionID = Utils.createUUID();

    this.sessionID = sessionID;
    this.sessionDate = Utils.dbtoday();
    this.storage.set('sessionID', this.sessionID);
    this.storage.set('sessionDate', Utils.dbtoday());

    return this.sessionID;
  }
}
