import { Injectable } from '@angular/core';
import { UserService } from './user.service';
import { Storage } from '@ionic/storage';

@Injectable({
  providedIn: 'root'
})
export class StorageService {

  constructor(private storage: Storage, private userService: UserService) {}

  public getVillage() {
    return this.storage.get('villages');
  }

  public getZone() {
    return this.storage.get('zones');
  }

  public getDistrict() {
    return this.storage.get('districts');
  }

  public getState() {
    return this.storage.get('states');
  }

  public getCountry() {
    return this.storage.get('countries');
  }

  public getBovine() {
    return this.storage.get('bovines');
  }
  
  public getUser() {
    return this.storage.get('user');
  }

  public getProduct() {
    return this.storage.get('products')
  }

  public getOrder() {
    return this.storage.get('orders')
  }

  public getDrs() {
    return this.storage.get('drs')
  }

  public getNdr() {
    return this.storage.get('ndr');
  }

  public drsDate() {
    return this.storage.get('drsDate')
  }

  public getSessionID() {
    return this.storage.get('sessionID')
  }

  public sessionDate() {
    return this.storage.get('sessionDate')
  }

  public getCategories() {
    return this.storage.get('categories')
  }

  public getSubcategories() {
    return this.storage.get('subcategories')
  }

  public getFodders() {
    return this.storage.get('fodders')
  }

}
