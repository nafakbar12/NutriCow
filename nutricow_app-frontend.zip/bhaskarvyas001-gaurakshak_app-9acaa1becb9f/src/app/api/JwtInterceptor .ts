// JWT interceptor
import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UserService } from './user.service';


@Injectable()
export class JwtInterceptor implements HttpInterceptor {
    constructor(private userService: UserService) {}

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        // add authorization header with jwt token if available
        const currentAuthToken = this.userService.user ? this.userService.user.api_token : null;
        if (currentAuthToken) {
            const headers = {
                'Authorization': `Bearer ${currentAuthToken}`,
            };
            if(request.url.indexOf("speechtotext") > -1){
                headers['enctype'] = 'multipart/form-data';
            }else{
                if (request.responseType === 'json') {
                    headers['Content-Type'] = 'application/json';
                }
            }
            request = request.clone({
                setHeaders: headers
            });
        }

        return next.handle(request);
    }
}