import { ToastController, LoadingController } from "@ionic/angular";
import { HttpHeaders } from "@angular/common/http";
import { UserService } from "./user.service";

export default class Utils {
  //static baseUrl:string = "http://127.0.0.1:8000/api/";
  static baseUrl:string = "https://phplaravel-1085149-3796880.cloudwaysapps.com/api/";

  constructor(private userService: UserService) {}

  static  toastController = new ToastController();

  static showMessage(type, message): void{
    const toast = Utils.toastController.create({
      message: message,
      duration: 4000,
      color: type
    }).then(toast => {
      toast.present();
    });
  }

  static loadingController = new LoadingController();
  static loading = null;
  static dismissRequested = 0;

  static showLoader(){
    Utils.loadingController.create({
      message: 'Please wait...',
      translucent: true
    }).then(loading => {
      Utils.loading = loading;
      Utils.loading.present();
      if(Utils.dismissRequested > 0){
        Utils.loading.dismiss();
        Utils.dismissRequested--;
      }
    });
  }

  static dismissLoader(){
    if(Utils.loading){
      Utils.loading.dismiss();
    }else{
      Utils.dismissRequested++;
    }
  }

  static getStatuses(type: string): string[]{
    let pendingStatuses = ["OUT FOR DELIVERY", "OUT FOR PICKUP"];
    let completedStatuses = ["DELIVERED", "Pickup Done"];
    let failedStatuses = ["UNDELIVERED", "Pickup Not Done", "Pickup Cancelled"];
    switch (type) {
      case 'pending':
        return pendingStatuses;
      case 'completed':
        return completedStatuses;
      case 'failed':
        return failedStatuses;
      default:
        return [];
    }
  }

  static dataURLtoBlob(dataurl: string) {
    var arr = dataurl.split(','), mime = arr[0].match(/:(.*?);/)[1],
        bstr = atob(arr[1]), n = bstr.length, u8arr = new Uint8Array(n);
    while(n--){
        u8arr[n] = bstr.charCodeAt(n);
    }
    return new Blob([u8arr], {type:mime});
}

  static createUUID() {
    // http://www.ietf.org/rfc/rfc4122.txt
    var s = [];
    var hexDigits = "0123456789abcdef";
    for (var i = 0; i < 36; i++) {
        s[i] = hexDigits.substr(Math.floor(Math.random() * 0x10), 1);
    }
    s[14] = "4";  // bits 12-15 of the time_hi_and_version field to 0010
    s[19] = hexDigits.substr((s[19] & 0x3) | 0x8, 1);  // bits 6-7 of the clock_seq_hi_and_reserved to 01
    s[8] = s[13] = s[18] = s[23] = "-";

    var uuid = s.join("");
    return uuid;
}

  static today(){
    var now = new Date();
    var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    var formattedDate = now.getDate()+" "+months[now.getMonth()]+" "+now.getFullYear();
    return formattedDate;
  }
  
  static dbtoday(){
    var now = new Date();
    var formattedDate = now.getFullYear()+"-"+Utils.addZ((now.getMonth()+1))+"-"+Utils.addZ(now.getDate());
    return formattedDate;
  }

  static timestamp(){
    //yyyy-MM-dd HH:mm:ss format
    var date = new Date();
    return date.toJSON().slice(0,10).replace(new RegExp("-", 'g'),"/" ).split("/").join("-")+" "+date.toJSON().slice(11,19);
  }
  
  static addZ(n: number){return n<10? '0'+n:''+n;}
}