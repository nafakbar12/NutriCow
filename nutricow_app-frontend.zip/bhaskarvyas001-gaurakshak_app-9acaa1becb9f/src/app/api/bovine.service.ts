import { Injectable } from '@angular/core';
import { HttpClient } from  '@angular/common/http';
import { Observable } from  'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import  'rxjs/add/operator/map';
import { Storage } from '@ionic/storage';
import Utils from './utils';
import { Geoposition } from '@ionic-native/geolocation/ngx';
import { StatusRequest } from '../models/statusRequest';
import { StorageService } from './storage.service';
import { Fodder } from '../models/fodder';
import { Subcategory } from '../models/subcategory';
import { Category } from '../models/category';

@Injectable({
  providedIn: 'root'
})
export class BovineService {
  public categories: Category[] = [];
  public subcategories: Subcategory[] = [];
  public fodders: Fodder[] = [];

  constructor(private  httpClient : HttpClient, private storage: Storage, private storageService: StorageService) { 
    //load other data from local storage
    Utils.showLoader();
    this.storageService.getCategories().then((categries)=>{
      Utils.dismissLoader()
      if(categries){
        this.categories = categries;
      }
    },(error)=>{
      Utils.dismissLoader()
    })

    Utils.showLoader();
    this.storageService.getSubcategories().then((subcategories)=>{
      Utils.dismissLoader()
      if(subcategories){
        this.subcategories = subcategories;
      }
    },(error)=>{
      Utils.dismissLoader()
    })

    Utils.showLoader();
    this.storageService.getFodders().then((fodders)=>{
      Utils.dismissLoader()
      if(fodders){
        this.fodders = fodders;
      }
    },(error)=>{
      Utils.dismissLoader()
    })
  }

  getCategories():Observable<Category[]>{
    this.categories = null;
    this.storage.set('categries', this.categories);
    
    Utils.showLoader()
    return this.httpClient
    .get(Utils.baseUrl + 'ncicategories')
    .map((response: any[])  => {
      Utils.dismissLoader()
      this.categories = response;
      this.storage.set('categories', this.categories);
      return response;
    })
    .catch((err)=>{
      Utils.dismissLoader()
      Utils.showMessage('danger', err.message);
      return Observable.throw(err);
    });
  }

  getSubcategories():Observable<Subcategory[]>{
    this.subcategories = null;
    this.storage.set('subcategries', this.subcategories);
    
    Utils.showLoader()
    return this.httpClient
    .get(Utils.baseUrl + 'ncisubcategories')
    .map((response: any[])  => {
      Utils.dismissLoader()
      this.subcategories = response;
      this.storage.set('subcategories', this.subcategories);
      return response;
    })
    .catch((err)=>{
      Utils.dismissLoader()
      Utils.showMessage('danger', err.message);
      return Observable.throw(err);
    });
  }

  getFodders():Observable<Fodder[]>{
    this.fodders = null;
    this.storage.set('fodders', this.fodders);
    
    Utils.showLoader()
    return this.httpClient
    .get(Utils.baseUrl + 'ncifodders')
    .map((response: any[])  => {
      Utils.dismissLoader()
      this.fodders = response;
      this.storage.set('fodders', this.fodders);
      return response;
    })
    .catch((err)=>{
      Utils.dismissLoader()
      Utils.showMessage('danger', err.message);
      return Observable.throw(err);
    });
  }

  nutricheck(payload): Observable<any>{
    Utils.showLoader()
    return this.httpClient
    .post(Utils.baseUrl + 'nutricheck', payload)
    .map((response: any[])  => {
      Utils.dismissLoader()
      return response;
    })
    .catch((err)=>{
      Utils.dismissLoader()
      Utils.showMessage('danger', err.message);
      return Observable.throw(err);
    });
  }

  nutrirecommend(foddersData): Observable<any>{
    Utils.showLoader()
    return this.httpClient
    .post(Utils.baseUrl + 'nutrirecommend', foddersData)
    .map((response: any[])  => {
      Utils.dismissLoader()
      return response;
    })
    .catch((err)=>{
      Utils.dismissLoader()
      Utils.showMessage('danger', err.message);
      return Observable.throw(err);
    });
  }

  uploadSpeechFile(blob, filename): Observable<any> {
    Utils.showLoader();
    let formData = new FormData();
    formData.append("audio", blob as Blob, filename);

    return this.httpClient
    .post(Utils.baseUrl + 'speechtotext', formData)
    .map(response  => {
      Utils.dismissLoader()
      return response;
    })
    .catch((err)=>{
      Utils.dismissLoader()
      Utils.showMessage('danger', err.message);
      return Observable.throw(err);
    });
  }

  clearStorageData(){
    this.categories = null;
    this.subcategories = null;
    this.fodders = null;
    this.storage.set('categories', this.categories);
    this.storage.set('subcategories', this.subcategories);
    this.storage.set('fodders', this.fodders);
  }
}
