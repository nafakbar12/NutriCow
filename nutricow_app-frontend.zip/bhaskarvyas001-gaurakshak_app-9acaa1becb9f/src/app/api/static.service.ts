import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { StorageService } from './storage.service';
import Utils from './utils';
import { Observable } from 'rxjs';
import { Village } from '../models/village';
import { Zone } from '../models/zone';
import { District } from '../models/district';
import { State } from '../models/state';
import { Country } from '../models/country';
import { Storage } from '@ionic/storage';
import { Bovine } from '../models/bovine';

@Injectable({
  providedIn: 'root'
})
export class StaticService {
  public villages: Village[] = [];
  public zones: Zone[] = [];
  public districts: District[] = [];
  public states: State[] = [];
  public countries: Country[] = [];
  public bovines: Bovine[] = [];
  
  constructor(private  httpClient : HttpClient, private storage: Storage, private storageService: StorageService) {
    //load other data from local storage
    //Utils.showLoader();
    this.storageService.getVillage().then((villages)=>{
      Utils.dismissLoader()
      if(villages){
        this.villages = villages;
      }
    },(error)=>{
      Utils.dismissLoader()
    })

    this.storageService.getZone().then((zones)=>{
      Utils.dismissLoader()
      if(zones){
        this.zones = zones;
      }
    },(error)=>{
      Utils.dismissLoader()
    })

    this.storageService.getDistrict().then((districts)=>{
      Utils.dismissLoader()
      if(districts){
        this.districts = districts;
      }
    },(error)=>{
      Utils.dismissLoader()
    })

    this.storageService.getState().then((states)=>{
      Utils.dismissLoader()
      if(states){
        this.states = states;
      }
    },(error)=>{
      Utils.dismissLoader()
    })

    this.storageService.getCountry().then((countries)=>{
      Utils.dismissLoader()
      if(countries){
        this.countries = countries;
      }
    },(error)=>{
      Utils.dismissLoader()
    })

    this.storageService.getBovine().then((bovines)=>{
      Utils.dismissLoader()
      if(bovines){
        this.bovines = bovines;
      }
    },(error)=>{
      Utils.dismissLoader()
    })
  }

  clearStorageData(){
    this.villages = null;
    this.zones = null;
    this.districts = null;
    this.states = null;
    this.countries = null;
    this.bovines = null;
    this.storage.set('villages', this.villages);
    this.storage.set('zones', this.zones);
    this.storage.set('districts', this.districts);
    this.storage.set('states', this.states);
    this.storage.set('countries', this.countries);
    this.storage.set('bovines', this.bovines);
  }

  public getVillages(): Observable<Village[]> {
    //Utils.showLoader()
    return this.httpClient
    .get(Utils.baseUrl + 'villages')
    .map((response:Village[])  => {
      Utils.dismissLoader();
      this.villages = response;
      this.storage.set('villages', this.villages);
      return  this.villages;
    })
    .catch((err)=>{
      Utils.dismissLoader()
      Utils.showMessage('danger', err.message);
      return Observable.throw(err);
    });
  }

  public getZones(): Observable<Zone[]> {
    //Utils.showLoader()
    return this.httpClient
    .get(Utils.baseUrl + 'zones')
    .map((response:Zone[])  => {
      Utils.dismissLoader();
      this.zones = response;
      this.storage.set('zones', this.zones);
      return  this.zones;
    })
    .catch((err)=>{
      Utils.dismissLoader()
      Utils.showMessage('danger', err.message);
      return Observable.throw(err);
    });
  }

  public getDistrict(): Observable<District[]> {
    //Utils.showLoader()
    return this.httpClient
    .get(Utils.baseUrl + 'districts')
    .map((response:District[])  => {
      Utils.dismissLoader();
      this.districts = response;
      this.storage.set('districts', this.districts);
      return  this.districts;
    })
    .catch((err)=>{
      Utils.dismissLoader()
      Utils.showMessage('danger', err.message);
      return Observable.throw(err);
    });
  }

  public getStates(): Observable<State[]> {
    //Utils.showLoader()
    return this.httpClient
    .get(Utils.baseUrl + 'states')
    .map((response:State[])  => {
      Utils.dismissLoader();
      this.states = response;
      this.storage.set('states', this.states);
      return  this.states;
    })
    .catch((err)=>{
      Utils.dismissLoader()
      Utils.showMessage('danger', err.message);
      return Observable.throw(err);
    });
  }

  public getCountries(): Observable<Country[]> {
    //Utils.showLoader()
    return this.httpClient
    .get(Utils.baseUrl + 'countries')
    .map((response:Country[])  => {
      Utils.dismissLoader();
      this.countries = response;
      this.storage.set('countries', this.countries);
      return  this.countries;
    })
    .catch((err)=>{
      Utils.dismissLoader()
      Utils.showMessage('danger', err.message);
      return Observable.throw(err);
    });
  }

  public getBovines(): Observable<Bovine[]> {
    //Utils.showLoader()
    return this.httpClient
    .get(Utils.baseUrl + 'bovines')
    .map((response:Bovine[])  => {
      Utils.dismissLoader();
      this.bovines = response;
      this.storage.set('bovines', this.bovines);
      return  this.bovines;
    })
    .catch((err)=>{
      Utils.dismissLoader()
      Utils.showMessage('danger', err.message);
      return Observable.throw(err);
    });
  }

  public getRegDistrict(): Observable<District[]> {
    //Utils.showLoader()
    return this.httpClient
    .get(Utils.baseUrl + 'regdistricts')
    .map((response:District[])  => {
      Utils.dismissLoader();
      this.districts = response;
      this.storage.set('districts', this.districts);
      return  this.districts;
    })
    .catch((err)=>{
      Utils.dismissLoader()
      Utils.showMessage('danger', err.message);
      return Observable.throw(err);
    });
  }

  public getRegStates(): Observable<State[]> {
    //Utils.showLoader()
    return this.httpClient
    .get(Utils.baseUrl + 'regstates')
    .map((response:State[])  => {
      Utils.dismissLoader();
      this.states = response;
      this.storage.set('states', this.states);
      return  this.states;
    })
    .catch((err)=>{
      Utils.dismissLoader()
      Utils.showMessage('danger', err.message);
      return Observable.throw(err);
    });
  }

  public loadRegisterData(){
    let self = this;
    setTimeout(function() {
      self.getRegDistrict().subscribe(()=>{
        Utils.dismissLoader();
      });
    }, 300);

    setTimeout(function() {
      self.getRegStates().subscribe(()=>{
        Utils.dismissLoader();
      });
    }, 400);
  }

  public loadAllStaticData(){
    let self = this;
    setTimeout(function() {
      self.getVillages().subscribe(()=>{
        Utils.dismissLoader();
      });
    }, 100);

    setTimeout(function() {
      self.getZones().subscribe(()=>{
        Utils.dismissLoader();
      });
    }, 200);

    setTimeout(function() {
      self.getDistrict().subscribe(()=>{
        Utils.dismissLoader();
      });
    }, 300);

    setTimeout(function() {
      self.getStates().subscribe(()=>{
        Utils.dismissLoader();
      });
    }, 400);

    setTimeout(function() {
      self.getCountries().subscribe(()=>{
        Utils.dismissLoader();
      });
    }, 500);

    setTimeout(function() {
      self.getBovines().subscribe(()=>{
        Utils.dismissLoader();
      });
    }, 600);
  }
}
