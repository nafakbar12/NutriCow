import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Waybill } from 'src/app/models/waybill';
import { StatusRequest } from 'src/app/models/statusRequest';
import { UserService } from 'src/app/api/user.service';
import Utils from 'src/app/api/utils';
import { WaybillService } from 'src/app/api/waybill.service';
import { Geolocation, Geoposition } from '@ionic-native/geolocation/ngx';
import  SignaturePad  from 'signature_pad';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-logs',
  templateUrl: './logs.component.html',
  styleUrls: ['./logs.component.scss'],
})
export class LogsComponent implements OnInit {  
  public item: Waybill = null;
  public statusRequest: StatusRequest = new StatusRequest();
  public receiverType: string = 'Other';
  public currentGeolocation: Geoposition;
  private signaturePad: any;
  public minDate: string = new Date().toISOString();
  public maxDate : any = (new Date()).getFullYear() + 1;

  constructor(private route: ActivatedRoute, private userService: UserService, 
      private waybillService: WaybillService, private router: Router,
      private geolocation: Geolocation, private ionicAlert: AlertController) {
    this.statusRequest.dstatus = 'DELIVERED';
    this.statusRequest.rstatus = "";
  }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.item = JSON.parse(params['item']); 
      if(this.item.awb.slice(-2) == "RV"){
        this.statusRequest.dstatus = 'Pickup Not Done';
      }else{
        this.initializeSignaturePad();
      }
    });

    //also get the current location
    this.geolocation.getCurrentPosition().then((location: Geoposition) => {
      if(location.coords && this.userService.user){
        this.currentGeolocation = location;
        this.waybillService.saveGpsLocaton(location, this.userService.user.mobile, this.userService.user.name).subscribe((response)=>{
          Utils.showMessage('success', location.coords.latitude +' - '+ location.coords.longitude);
        })
      }
    }).catch((error) => {
      //console.log('Error getting location', error);
      //alert(error);
    });
  }

  updateWaybill(codCollected = false) {
    if(this.item.collectable_value > 0 && this.statusRequest.dstatus == 'DELIVERED' && codCollected == false){
      this.codCollectedConfirm();
    }else if(this.isValidUpdatable()){
      this.statusRequest.orders = [this.item.awb];
      //this.statusRequest.branch_id = this.userService.user.branch_id;
      this.statusRequest.delivPersonId = this.userService.user.id;
      this.statusRequest.user = this.userService.user.name;
      this.statusRequest.signatureFileName = this.item.awb+'_'+Utils.dbtoday()+'.png';

      if(this.currentGeolocation){
        this.statusRequest.latitude =  this.currentGeolocation.coords.latitude;
        this.statusRequest.longitude =  this.currentGeolocation.coords.longitude;
      }

      //upload the signature image in background
      if(this.statusRequest.dstatus === 'DELIVERED'){
        this.waybillService.uploadSignature(this.signaturePad.toDataURL('image/png'), this.item.awb).subscribe(response=>{
          Utils.showMessage('success', 'SUCCESS:: Signature uploaded');
        });
      }

      this.waybillService.updateStatus(this.statusRequest).subscribe((response)=>{
        //response = JSON.parse(response);
        //if(response.success > 0){
        if(JSON.parse(response).success > 0){
          Utils.showMessage('success', 'SUCCESS:: Updated waybill');
          this.waybillService.updateWaybillinList(this.item.awb, this.statusRequest.dstatus);
          this.router.navigate(['/drs']);
        }else{
          Utils.showMessage('danger', 'FAILED:: To Update waybill. Details:: '+response);
        }
      });
    }
  }

  isValidUpdatable(): boolean {
    let isValid = true;
    if(this.statusRequest.dstatus === undefined){
      Utils.showMessage('danger', 'FAILED:: Please select STATUS');
      isValid = false;
    }else if((this.statusRequest.dstatus == 'UNDELIVERED' || this.statusRequest.dstatus == 'Pickup Not Done') && this.statusRequest.ndrid === undefined){
      Utils.showMessage('danger', 'FAILED:: Please select NDR');
      isValid = false;
    }else if((this.statusRequest.dstatus == 'UNDELIVERED' || this.statusRequest.dstatus == 'Pickup Not Done') && this.statusRequest.ndrid == '30' && 
          this.statusRequest.ndrdate === undefined){
      Utils.showMessage('danger', 'FAILED:: Please select NDR DATE');
      isValid = false;
    }else if(this.statusRequest.dstatus == 'DELIVERED' && (this.statusRequest.receiver_name === undefined ||  
        this.statusRequest.receiver_number === undefined)){
        Utils.showMessage('danger', 'FAILED:: Please enter Receiver NAME & MOBILE');
        isValid = false;
    }else if(this.statusRequest.dstatus == 'DELIVERED' && this.signaturePad.isEmpty()){
        Utils.showMessage('danger', 'FAILED:: Please get Receiver Signature');
        isValid = false;
    }
    return isValid;
  }

  async codCollectedConfirm() {
    const alert = await this.ionicAlert.create({
      header: 'Confirm',
      message: '<h3>Have you collected COD Amount: </h3><h1 align="center">&#8377;'+this.item.collectable_value+'</h1>',
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary',
          handler: (blah) => {
            Utils.showMessage('danger', 'FAILED:: Please collect the COD Amount to continue');
          }
        }, {
          text: 'Yes',
          handler: () => {
            this.updateWaybill(true);
          }
        }
      ]
    });
    await alert.present();
  }

  receiverTypeChange(): void {
    if(this.receiverType == 'Self'){
      this.statusRequest.receiver_name = this.item.dealer;
      this.statusRequest.receiver_number = this.item.mobile;
    }
  }

  statusChange():void {
    if(this.statusRequest.dstatus == 'DELIVERED'){
      this.initializeSignaturePad();
    }
  }

  initializeSignaturePad(): void{
    let _this=this;
    setTimeout(() => {
      this.signaturePad = new SignaturePad(document.getElementById('signature-pad') as HTMLCanvasElement, {
        backgroundColor: 'rgba(255, 255, 255, 1)',
        penColor: 'rgb(0, 0, 0)'
      });
      
      //var saveButton = document.getElementById('save');
      var cancelButton = document.getElementById('clear');
      
      /*saveButton.addEventListener('click', function (event) {
        var data = _this.signaturePad.toDataURL('image/png');
        console.log(data);
      });*/
      
      cancelButton.addEventListener('click', function (event) {
        _this.signaturePad.clear();
      });
    }, 500);
  }

  navigateToPaymentPage(item){
    this.router.navigate(['/payment', {item: JSON.stringify(item)}]);
  }

  isCompletedOrder(item){
    return Utils.getStatuses('completed').indexOf(item.status) > -1;
  }
}
