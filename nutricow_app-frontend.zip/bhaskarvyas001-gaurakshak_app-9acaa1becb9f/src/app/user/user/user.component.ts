import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { StaticService } from 'src/app/api/static.service';
import { StorageService } from 'src/app/api/storage.service';
import { UserService } from 'src/app/api/user.service';
import Utils from 'src/app/api/utils';
import { Bovine } from 'src/app/models/bovine';
import { Farmer } from 'src/app/models/farmer';
import { Profile } from 'src/app/models/profile';
import { User } from 'src/app/models/user';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss'],
})
export class UserComponent implements OnInit {
  public user:User = new User();
  public profile:Profile = new Profile();
  public farmer:Farmer = new Farmer();
  public bovine:Bovine = new Bovine();

  constructor(public userService: UserService, 
    private storageService: StorageService, private router: Router, 
    private activatedRoute: ActivatedRoute, private staticService: StaticService) { 
      this.activatedRoute.queryParams.subscribe(params => {
        this.user.user_type = params['type'];
        this.user.profile = this.profile;

        this.farmer.user_type = params['type'];
        this.farmer.profile = this.profile;
        this.farmer.bovine = this.bovine;
      }); 
  }

  ngOnInit() {
    if(this.staticService.bovines.length == 0 || this.staticService.villages.length == 0 || this.staticService.zones.length == 0 || 
      this.staticService.districts.length == 0 || this.staticService.states.length == 0 || this.staticService.countries.length == 0){
        this.staticService.loadAllStaticData();
    }
  }

  saveUser(){
    let postData = this.user;
    if(this.user.user_type == "Farmer"){
      postData = this.farmer;
    }
    this.userService.saveUser(postData).subscribe((response)=>{
      let message = "User created";
      if(!response.id){
        message = response.error;
      }
      Utils.showMessage(response.id ? 'success':'danger', message);
      if(response.id){
        this.router.navigate(['/home']);
      }
    });
  }
}
