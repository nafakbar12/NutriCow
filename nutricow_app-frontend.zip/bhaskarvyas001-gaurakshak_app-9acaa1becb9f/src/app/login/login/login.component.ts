import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StorageService } from 'src/app/api/storage.service';
import { UserService } from 'src/app/api/user.service';
import Utils from 'src/app/api/utils';
import { WaybillService } from 'src/app/api/waybill.service';
import { User } from 'src/app/models/user';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  public item = {src:"assets/icon/gaurakshak-logo.png"};
  public credentials = {mobile: null, password: null};

  constructor(private router: Router, private userService: UserService, private waybillService: WaybillService, 
    private storageService: StorageService) {
  }

  ngOnInit() { 
    if(this.userService.user){
      this.router.navigate(['/home']);
    }
  }

  login = function(){
    if(this.credentials.mobile && this.credentials.mobile.length != 10){
      Utils.showMessage('danger', "Mobile number should be 10 digits");
    }else{
      this.userService.login(this.credentials).subscribe((user : User)=>{
        this.userService.user = user;
        this.router.navigate(['/home']);
      });
    }
  }
  
}
  

