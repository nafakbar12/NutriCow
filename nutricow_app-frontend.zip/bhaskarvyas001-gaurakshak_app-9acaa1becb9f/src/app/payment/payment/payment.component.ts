import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Waybill } from 'src/app/models/waybill';
import { Location } from '@angular/common';
import { UserService } from 'src/app/api/user.service';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.scss'],
})
export class PaymentComponent implements OnInit {

  public payment = {src: "assets/icon/bharatpe.jpg"};
  public item: Waybill = null;
  
  constructor(private router: Router, private route: ActivatedRoute, private location: Location,private userService: UserService) {
 if (this.userService.user.mobile == 1){this.payment.src = "assets/icon/bharatpe.jpg"}
 else{this.payment.src = "assets/icon/bharatpe1.jpg"}
   }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.item = JSON.parse(params['item']); 
    });
  }

  navigateToPreviousPage(){
    //this.router.navigate(['/payment', {item: JSON.stringify(this.item)}]);
    this.location.back();
  }

}
