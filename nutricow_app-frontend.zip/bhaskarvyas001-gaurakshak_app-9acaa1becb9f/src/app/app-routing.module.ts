import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'home',
    loadChildren: () => import('./home/home/home.module').then( m => m.HomeRoutingModule)
  },
  {
    path: 'profile',
    loadChildren: () => import('./profile/profile/profile.module').then( m => m.ProfileRoutingModule)
  },
  {
    path: 'order',
    loadChildren: () => import('./order/order/order.module').then( m => m.OrderComponentModule)
  },
  {
    path: 'onBoardUser',
    loadChildren: () => import('./user/user/user.module').then( m => m.UserRoutingModule)
  },
  {
    path: 'logout',
    loadChildren: () => import('./logout/logout/logout.module').then( m => m.LogoutRoutingModule)
  },

  {
  path: 'login',
    loadChildren: () => import('./login/login/login.module').then( m => m.LoginComponentModule)
  },
  {
    path: 'register',
    loadChildren: () => import('./register/register/register.module').then( m => m.RegisterComponentModule)
  },
  {
    path: 'logs',
    loadChildren: () => import('./logs/logs/logs.module').then( m => m.LogsComponentModule)
  },
  {
    path: 'payment',
    loadChildren: () => import('./payment/payment/payment.module').then( m => m.PaymentComponentModule)
  },

  {
    path: 'shop',
    loadChildren: () => import('./shop/shop/shop.module').then( m => m.ShopComponentModule)
  },
  {
    path: 'video',
    loadChildren: () => import('./video/video/video.module').then( m => m.VideoComponentModule)
  },
  {
    path: 'nutricheck',
    loadChildren: () => import('./nutricheck/nutricheck/nutricheck.module').then( m => m.NutricheckComponentModule)
  },
  {
    path: 'history',
    loadChildren: () => import('./nutricheck/nutricheck/nutricheck.module').then( m => m.NutricheckComponentModule)
  },   
];



@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
