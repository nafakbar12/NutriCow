import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/api/user.service';
import { Storage } from '@ionic/storage';
import { OrderService } from 'src/app/api/order.service';
import { Order } from 'src/app/models/order';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.scss'],
})
export class OrderComponent implements OnInit {  
  public items: Array<Order> = [];

  constructor(private orderService: OrderService, private router: Router, 
              private userService: UserService,
              private storage: Storage) {
  }

  ngOnInit() {
    this.orderService.orders().subscribe((orders) =>{
      this.items = orders;
    })
  }

  getDate(text){
    return text.split(" ")[0];
  }
}
