import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { RouterModule } from '@angular/router';
import { BarcodeScanner } from "@ionic-native/barcode-scanner/ngx";
import { OrderComponent } from './order.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild([
      {
        path: '',
        component: OrderComponent
      }
    ])
  ],
  providers: [
    BarcodeScanner
  ],
  declarations: [OrderComponent]
})
export class OrderComponentModule {}
