## Installation

App requires [Node.js](https://nodejs.org/) v10+ to run.

Install the dependencies and devDependencies and start the server.

```sh
cd online-xpress-app-v-2
npm install
npm start
```

For production environments...

```sh
npm install --production
NODE_ENV=production node app
```

For building the `APK` file
please refer the link [DOCS](https://ionicframework.com/docs/developing/android)  

- Step 1: Generate the native project, if it does not already exist.
For Capacitor, run the following:
```sh
$ ionic capacitor add android
```

For Cordova, run the following:
```sh
$ ionic cordova prepare android
```

- Step 2: Develop the Ionic app and sync it to the native project.
```sh
$ ionic capacitor copy android
```

- Step 3: To start a live-reload server run the following command.
```sh
ionic capacitor run android -l --host=YOUR_IP_ADDRESS
```

- Step 4: To get the SDK
```sh
Delete the WWW folder first

ionic build or npm run build
npx cap sync 
npx cap copy
npx cap run android or npx cap open android
```

- TIP: try wireless debugging in Android studio to test the App
Open the following menu on your phone: Settings > Developer options > Wireless debugging

- The generated APK file is found here
```sh
E:\workspacePHP\gaurakshak_app\android\app\build\outputs\apk\debug
```

- To generate icon
First, install cordova-res:
npm install -g cordova-res
```sh
cordova-res android --skip-config --copy
npx capacitor-assets generate --android --assetPath resources/android --androidProject android
```

OR

The word doc [here](https://docs.google.com/document/d/1olOIPzGE4z9q2KYQqeNvmhqOU975m8nd/edit?usp=sharing&ouid=101622106638783644782&rtpof=true&sd=true)


https://stackoverflow.com/questions/61122823/ionic-5-capacitor-android-project-not-sync
